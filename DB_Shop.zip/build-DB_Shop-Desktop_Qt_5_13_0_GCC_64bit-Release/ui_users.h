/********************************************************************************
** Form generated from reading UI file 'users.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USERS_H
#define UI_USERS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_Users
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QTableView *tbl_users;
    QPushButton *btn_deleteuser;
    QComboBox *combo_type;

    void setupUi(QDialog *Users)
    {
        if (Users->objectName().isEmpty())
            Users->setObjectName(QString::fromUtf8("Users"));
        Users->resize(1000, 600);
        lbl_BG = new QLabel(Users);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 1000, 600));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(53, 133, 151);"));
        lbl_border = new QLabel(Users);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(15, 15, 970, 570));
        lbl_border->setStyleSheet(QString::fromUtf8("border:5px solid rgb(244, 168, 150)"));
        tbl_users = new QTableView(Users);
        tbl_users->setObjectName(QString::fromUtf8("tbl_users"));
        tbl_users->setGeometry(QRect(40, 85, 920, 480));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        tbl_users->setFont(font);
        tbl_users->setStyleSheet(QString::fromUtf8(""));
        btn_deleteuser = new QPushButton(Users);
        btn_deleteuser->setObjectName(QString::fromUtf8("btn_deleteuser"));
        btn_deleteuser->setGeometry(QRect(40, 40, 35, 35));
        QFont font1;
        font1.setPointSize(17);
        font1.setBold(true);
        font1.setWeight(75);
        btn_deleteuser->setFont(font1);
        btn_deleteuser->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);\n"
"color: rgb(255, 255, 255);"));
        combo_type = new QComboBox(Users);
        combo_type->addItem(QString());
        combo_type->addItem(QString());
        combo_type->addItem(QString());
        combo_type->setObjectName(QString::fromUtf8("combo_type"));
        combo_type->setGeometry(QRect(90, 40, 86, 35));

        retranslateUi(Users);

        QMetaObject::connectSlotsByName(Users);
    } // setupUi

    void retranslateUi(QDialog *Users)
    {
        Users->setWindowTitle(QCoreApplication::translate("Users", "Manage Users", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        btn_deleteuser->setText(QCoreApplication::translate("Users", "-", nullptr));
        combo_type->setItemText(0, QCoreApplication::translate("Users", "All", nullptr));
        combo_type->setItemText(1, QCoreApplication::translate("Users", "Employees", nullptr));
        combo_type->setItemText(2, QCoreApplication::translate("Users", "Customers", nullptr));

    } // retranslateUi

};

namespace Ui {
    class Users: public Ui_Users {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USERS_H
