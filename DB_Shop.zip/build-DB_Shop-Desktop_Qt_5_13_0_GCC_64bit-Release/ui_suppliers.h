/********************************************************************************
** Form generated from reading UI file 'suppliers.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SUPPLIERS_H
#define UI_SUPPLIERS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_Suppliers
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QTableView *tbl_suppliers;
    QPushButton *btn_addsupplier;
    QPushButton *btn_deletesupplier;

    void setupUi(QDialog *Suppliers)
    {
        if (Suppliers->objectName().isEmpty())
            Suppliers->setObjectName(QString::fromUtf8("Suppliers"));
        Suppliers->resize(1000, 600);
        lbl_BG = new QLabel(Suppliers);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 1000, 600));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(53, 133, 151);"));
        lbl_border = new QLabel(Suppliers);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(15, 15, 970, 570));
        lbl_border->setStyleSheet(QString::fromUtf8("border:5px solid rgb(244, 168, 150)"));
        tbl_suppliers = new QTableView(Suppliers);
        tbl_suppliers->setObjectName(QString::fromUtf8("tbl_suppliers"));
        tbl_suppliers->setGeometry(QRect(40, 85, 920, 480));
        tbl_suppliers->setStyleSheet(QString::fromUtf8(""));
        tbl_suppliers->verticalHeader()->setVisible(false);
        btn_addsupplier = new QPushButton(Suppliers);
        btn_addsupplier->setObjectName(QString::fromUtf8("btn_addsupplier"));
        btn_addsupplier->setGeometry(QRect(40, 40, 35, 35));
        QFont font;
        font.setPointSize(17);
        font.setBold(true);
        font.setWeight(75);
        btn_addsupplier->setFont(font);
        btn_addsupplier->setStyleSheet(QString::fromUtf8("background-color: rgb(78, 154, 6);\n"
"color: rgb(255, 255, 255);"));
        btn_deletesupplier = new QPushButton(Suppliers);
        btn_deletesupplier->setObjectName(QString::fromUtf8("btn_deletesupplier"));
        btn_deletesupplier->setGeometry(QRect(80, 40, 35, 35));
        btn_deletesupplier->setFont(font);
        btn_deletesupplier->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);\n"
"color: rgb(255, 255, 255);"));

        retranslateUi(Suppliers);

        QMetaObject::connectSlotsByName(Suppliers);
    } // setupUi

    void retranslateUi(QDialog *Suppliers)
    {
        Suppliers->setWindowTitle(QCoreApplication::translate("Suppliers", "Suppliers", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        btn_addsupplier->setText(QCoreApplication::translate("Suppliers", "+", nullptr));
        btn_deletesupplier->setText(QCoreApplication::translate("Suppliers", "-", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Suppliers: public Ui_Suppliers {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SUPPLIERS_H
