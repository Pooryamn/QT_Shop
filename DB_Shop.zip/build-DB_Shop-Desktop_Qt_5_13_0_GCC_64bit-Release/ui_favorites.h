/********************************************************************************
** Form generated from reading UI file 'favorites.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FAVORITES_H
#define UI_FAVORITES_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_favorites
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QTableView *tbl_history;
    QPushButton *btn_delete;

    void setupUi(QDialog *favorites)
    {
        if (favorites->objectName().isEmpty())
            favorites->setObjectName(QString::fromUtf8("favorites"));
        favorites->resize(1000, 600);
        lbl_BG = new QLabel(favorites);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 1000, 600));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(53, 133, 151);"));
        lbl_border = new QLabel(favorites);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(15, 15, 970, 570));
        lbl_border->setStyleSheet(QString::fromUtf8("border:5px solid rgb(244, 168, 150)"));
        tbl_history = new QTableView(favorites);
        tbl_history->setObjectName(QString::fromUtf8("tbl_history"));
        tbl_history->setGeometry(QRect(40, 84, 920, 481));
        QFont font;
        font.setPointSize(13);
        font.setBold(true);
        font.setWeight(75);
        tbl_history->setFont(font);
        tbl_history->setStyleSheet(QString::fromUtf8(""));
        tbl_history->verticalHeader()->setVisible(false);
        btn_delete = new QPushButton(favorites);
        btn_delete->setObjectName(QString::fromUtf8("btn_delete"));
        btn_delete->setGeometry(QRect(40, 40, 41, 35));
        QFont font1;
        font1.setPointSize(19);
        font1.setBold(true);
        font1.setWeight(75);
        btn_delete->setFont(font1);
        btn_delete->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);\n"
"color: rgb(255, 255, 255);"));

        retranslateUi(favorites);

        QMetaObject::connectSlotsByName(favorites);
    } // setupUi

    void retranslateUi(QDialog *favorites)
    {
        favorites->setWindowTitle(QCoreApplication::translate("favorites", "Favorites ...", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        btn_delete->setText(QCoreApplication::translate("favorites", "-", nullptr));
    } // retranslateUi

};

namespace Ui {
    class favorites: public Ui_favorites {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FAVORITES_H
