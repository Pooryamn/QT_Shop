/********************************************************************************
** Form generated from reading UI file 'forget.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORGET_H
#define UI_FORGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_forget
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QLabel *lbl_email;
    QLineEdit *txt_user;
    QPushButton *btn_cancel;
    QPushButton *btn_recover;

    void setupUi(QDialog *forget)
    {
        if (forget->objectName().isEmpty())
            forget->setObjectName(QString::fromUtf8("forget"));
        forget->resize(600, 400);
        lbl_BG = new QLabel(forget);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 600, 400));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color:rgb(255,167,129);"));
        lbl_border = new QLabel(forget);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(15, 15, 570, 370));
        lbl_border->setStyleSheet(QString::fromUtf8("border:5px solid rgb(91, 14, 45);"));
        lbl_email = new QLabel(forget);
        lbl_email->setObjectName(QString::fromUtf8("lbl_email"));
        lbl_email->setGeometry(QRect(120, 100, 320, 30));
        QFont font;
        font.setPointSize(20);
        font.setBold(true);
        font.setWeight(75);
        lbl_email->setFont(font);
        lbl_email->setStyleSheet(QString::fromUtf8("color: rgb(91, 14, 45);"));
        txt_user = new QLineEdit(forget);
        txt_user->setObjectName(QString::fromUtf8("txt_user"));
        txt_user->setGeometry(QRect(120, 150, 360, 45));
        QFont font1;
        font1.setPointSize(18);
        font1.setBold(true);
        font1.setWeight(75);
        txt_user->setFont(font1);
        txt_user->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(91, 14, 45);\n"
"color: rgb(91, 14, 45);;"));
        txt_user->setAlignment(Qt::AlignCenter);
        btn_cancel = new QPushButton(forget);
        btn_cancel->setObjectName(QString::fromUtf8("btn_cancel"));
        btn_cancel->setGeometry(QRect(250, 290, 100, 40));
        QFont font2;
        font2.setPointSize(17);
        font2.setBold(true);
        font2.setWeight(75);
        font2.setKerning(true);
        btn_cancel->setFont(font2);
        btn_cancel->setStyleSheet(QString::fromUtf8("background-color: rgb(91, 14, 45);\n"
"color: rgb(255,167,129);\n"
""));
        btn_recover = new QPushButton(forget);
        btn_recover->setObjectName(QString::fromUtf8("btn_recover"));
        btn_recover->setGeometry(QRect(200, 240, 200, 40));
        QFont font3;
        font3.setPointSize(17);
        font3.setBold(true);
        font3.setWeight(75);
        btn_recover->setFont(font3);
        btn_recover->setStyleSheet(QString::fromUtf8("background-color: rgb(91, 14, 45);\n"
"color: rgb(255,167,129);\n"
""));
        QWidget::setTabOrder(txt_user, btn_recover);
        QWidget::setTabOrder(btn_recover, btn_cancel);

        retranslateUi(forget);

        QMetaObject::connectSlotsByName(forget);
    } // setupUi

    void retranslateUi(QDialog *forget)
    {
        forget->setWindowTitle(QCoreApplication::translate("forget", "Recover Password ...", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        lbl_email->setText(QCoreApplication::translate("forget", "Your Username :", nullptr));
        txt_user->setText(QString());
        btn_cancel->setText(QCoreApplication::translate("forget", "Cancel", nullptr));
        btn_recover->setText(QCoreApplication::translate("forget", "Send Password", nullptr));
    } // retranslateUi

};

namespace Ui {
    class forget: public Ui_forget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORGET_H
