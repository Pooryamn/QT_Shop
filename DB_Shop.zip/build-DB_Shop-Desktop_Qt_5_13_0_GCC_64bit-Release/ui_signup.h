/********************************************************************************
** Form generated from reading UI file 'signup.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SIGNUP_H
#define UI_SIGNUP_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_SignUp
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QLabel *lbl_firstname;
    QLineEdit *txt_name;
    QLabel *lbl_family;
    QLineEdit *txt_lastname;
    QLineEdit *txt_email;
    QLabel *lbl_email;
    QLabel *lbl_mobile;
    QLineEdit *txt_mobile;
    QLineEdit *txt_home;
    QLabel *lbl_home;
    QLineEdit *txt_year;
    QLabel *lbl_birth;
    QLabel *lbl_national;
    QLineEdit *txt_national;
    QGroupBox *gp_type;
    QRadioButton *radio_user;
    QRadioButton *redio_employee;
    QLabel *pic_profile;
    QPushButton *btn_load;
    QPushButton *btn_clear;
    QPushButton *btn_close;
    QPushButton *btn_cansel;
    QLabel *lbl_city;
    QLineEdit *txt_city;
    QLineEdit *txt_post;
    QLabel *lbl_post;
    QLineEdit *txt_user;
    QLabel *lbl_user;
    QLineEdit *txt_pass;
    QLabel *lbl_pass1;
    QLineEdit *txt_comfrim;
    QLabel *lbl_pass2;
    QLabel *lbl_pass2_2;
    QTextEdit *textEdit;
    QPushButton *btn_verify;
    QLineEdit *txt_month;
    QLabel *lbl_slah;
    QLabel *lbl_slah_2;
    QLineEdit *txt_day;

    void setupUi(QDialog *SignUp)
    {
        if (SignUp->objectName().isEmpty())
            SignUp->setObjectName(QString::fromUtf8("SignUp"));
        SignUp->resize(1000, 720);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Res/img/signup_icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        SignUp->setWindowIcon(icon);
        lbl_BG = new QLabel(SignUp);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 1000, 720));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(47,48,43);"));
        lbl_border = new QLabel(SignUp);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(10, 10, 970, 690));
        lbl_border->setStyleSheet(QString::fromUtf8("border:5px solid rgb(255,113,41)"));
        lbl_firstname = new QLabel(SignUp);
        lbl_firstname->setObjectName(QString::fromUtf8("lbl_firstname"));
        lbl_firstname->setGeometry(QRect(40, 200, 100, 20));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        lbl_firstname->setFont(font);
        lbl_firstname->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        txt_name = new QLineEdit(SignUp);
        txt_name->setObjectName(QString::fromUtf8("txt_name"));
        txt_name->setGeometry(QRect(40, 230, 250, 30));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setWeight(75);
        txt_name->setFont(font1);
        txt_name->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 133, 41);\n"
"color: rgb(78, 154, 6);"));
        txt_name->setAlignment(Qt::AlignCenter);
        lbl_family = new QLabel(SignUp);
        lbl_family->setObjectName(QString::fromUtf8("lbl_family"));
        lbl_family->setGeometry(QRect(40, 280, 100, 20));
        lbl_family->setFont(font);
        lbl_family->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        txt_lastname = new QLineEdit(SignUp);
        txt_lastname->setObjectName(QString::fromUtf8("txt_lastname"));
        txt_lastname->setGeometry(QRect(40, 310, 250, 30));
        txt_lastname->setFont(font1);
        txt_lastname->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 133, 41);\n"
"color: rgb(78, 154, 6);"));
        txt_lastname->setAlignment(Qt::AlignCenter);
        txt_email = new QLineEdit(SignUp);
        txt_email->setObjectName(QString::fromUtf8("txt_email"));
        txt_email->setGeometry(QRect(40, 390, 250, 30));
        txt_email->setFont(font1);
        txt_email->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 133, 41);\n"
"color: rgb(78, 154, 6);"));
        txt_email->setAlignment(Qt::AlignCenter);
        lbl_email = new QLabel(SignUp);
        lbl_email->setObjectName(QString::fromUtf8("lbl_email"));
        lbl_email->setGeometry(QRect(40, 360, 100, 20));
        lbl_email->setFont(font);
        lbl_email->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        lbl_mobile = new QLabel(SignUp);
        lbl_mobile->setObjectName(QString::fromUtf8("lbl_mobile"));
        lbl_mobile->setGeometry(QRect(40, 440, 141, 20));
        lbl_mobile->setFont(font);
        lbl_mobile->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        txt_mobile = new QLineEdit(SignUp);
        txt_mobile->setObjectName(QString::fromUtf8("txt_mobile"));
        txt_mobile->setGeometry(QRect(40, 470, 250, 30));
        txt_mobile->setFont(font1);
        txt_mobile->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 133, 41);\n"
"color: rgb(78, 154, 6);"));
        txt_mobile->setAlignment(Qt::AlignCenter);
        txt_home = new QLineEdit(SignUp);
        txt_home->setObjectName(QString::fromUtf8("txt_home"));
        txt_home->setGeometry(QRect(40, 550, 250, 30));
        txt_home->setFont(font1);
        txt_home->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 133, 41);\n"
"color: rgb(78, 154, 6);"));
        txt_home->setAlignment(Qt::AlignCenter);
        lbl_home = new QLabel(SignUp);
        lbl_home->setObjectName(QString::fromUtf8("lbl_home"));
        lbl_home->setGeometry(QRect(40, 520, 141, 16));
        lbl_home->setFont(font);
        lbl_home->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        txt_year = new QLineEdit(SignUp);
        txt_year->setObjectName(QString::fromUtf8("txt_year"));
        txt_year->setGeometry(QRect(370, 70, 51, 30));
        txt_year->setFont(font1);
        txt_year->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 133, 41)"));
        txt_year->setAlignment(Qt::AlignCenter);
        lbl_birth = new QLabel(SignUp);
        lbl_birth->setObjectName(QString::fromUtf8("lbl_birth"));
        lbl_birth->setGeometry(QRect(370, 40, 141, 16));
        lbl_birth->setFont(font);
        lbl_birth->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        lbl_national = new QLabel(SignUp);
        lbl_national->setObjectName(QString::fromUtf8("lbl_national"));
        lbl_national->setGeometry(QRect(40, 120, 100, 20));
        lbl_national->setFont(font);
        lbl_national->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        txt_national = new QLineEdit(SignUp);
        txt_national->setObjectName(QString::fromUtf8("txt_national"));
        txt_national->setGeometry(QRect(40, 150, 250, 30));
        txt_national->setFont(font1);
        txt_national->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 133, 41);\n"
"color: rgb(78, 154, 6);"));
        txt_national->setAlignment(Qt::AlignCenter);
        gp_type = new QGroupBox(SignUp);
        gp_type->setObjectName(QString::fromUtf8("gp_type"));
        gp_type->setGeometry(QRect(70, 20, 140, 90));
        gp_type->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        radio_user = new QRadioButton(gp_type);
        radio_user->setObjectName(QString::fromUtf8("radio_user"));
        radio_user->setGeometry(QRect(10, 30, 112, 23));
        radio_user->setFont(font);
        radio_user->setChecked(true);
        redio_employee = new QRadioButton(gp_type);
        redio_employee->setObjectName(QString::fromUtf8("redio_employee"));
        redio_employee->setGeometry(QRect(10, 60, 112, 23));
        redio_employee->setFont(font);
        pic_profile = new QLabel(SignUp);
        pic_profile->setObjectName(QString::fromUtf8("pic_profile"));
        pic_profile->setGeometry(QRect(720, 30, 240, 320));
        pic_profile->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 4px solid rgb(255, 113, 41);"));
        btn_load = new QPushButton(SignUp);
        btn_load->setObjectName(QString::fromUtf8("btn_load"));
        btn_load->setGeometry(QRect(780, 370, 120, 30));
        btn_load->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 113, 41);"));
        btn_clear = new QPushButton(SignUp);
        btn_clear->setObjectName(QString::fromUtf8("btn_clear"));
        btn_clear->setGeometry(QRect(780, 410, 120, 30));
        btn_clear->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 113, 41);"));
        btn_close = new QPushButton(SignUp);
        btn_close->setObjectName(QString::fromUtf8("btn_close"));
        btn_close->setGeometry(QRect(840, 650, 120, 30));
        btn_close->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 113, 41);"));
        btn_cansel = new QPushButton(SignUp);
        btn_cansel->setObjectName(QString::fromUtf8("btn_cansel"));
        btn_cansel->setGeometry(QRect(710, 650, 120, 30));
        btn_cansel->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 113, 41);"));
        lbl_city = new QLabel(SignUp);
        lbl_city->setObjectName(QString::fromUtf8("lbl_city"));
        lbl_city->setGeometry(QRect(370, 120, 100, 20));
        lbl_city->setFont(font);
        lbl_city->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        txt_city = new QLineEdit(SignUp);
        txt_city->setObjectName(QString::fromUtf8("txt_city"));
        txt_city->setGeometry(QRect(370, 150, 250, 30));
        txt_city->setFont(font1);
        txt_city->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 133, 41);\n"
"color: rgb(78, 154, 6);"));
        txt_city->setAlignment(Qt::AlignCenter);
        txt_post = new QLineEdit(SignUp);
        txt_post->setObjectName(QString::fromUtf8("txt_post"));
        txt_post->setGeometry(QRect(370, 230, 250, 30));
        txt_post->setFont(font1);
        txt_post->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 133, 41);\n"
"color: rgb(78, 154, 6);"));
        txt_post->setAlignment(Qt::AlignCenter);
        lbl_post = new QLabel(SignUp);
        lbl_post->setObjectName(QString::fromUtf8("lbl_post"));
        lbl_post->setGeometry(QRect(370, 200, 100, 20));
        lbl_post->setFont(font);
        lbl_post->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        txt_user = new QLineEdit(SignUp);
        txt_user->setObjectName(QString::fromUtf8("txt_user"));
        txt_user->setGeometry(QRect(370, 310, 250, 30));
        txt_user->setFont(font1);
        txt_user->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 133, 41);\n"
"color: rgb(78, 154, 6);"));
        txt_user->setAlignment(Qt::AlignCenter);
        lbl_user = new QLabel(SignUp);
        lbl_user->setObjectName(QString::fromUtf8("lbl_user"));
        lbl_user->setGeometry(QRect(370, 280, 100, 20));
        lbl_user->setFont(font);
        lbl_user->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        txt_pass = new QLineEdit(SignUp);
        txt_pass->setObjectName(QString::fromUtf8("txt_pass"));
        txt_pass->setGeometry(QRect(370, 390, 250, 30));
        txt_pass->setFont(font1);
        txt_pass->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 133, 41);\n"
"color: rgb(78, 154, 6);"));
        txt_pass->setAlignment(Qt::AlignCenter);
        lbl_pass1 = new QLabel(SignUp);
        lbl_pass1->setObjectName(QString::fromUtf8("lbl_pass1"));
        lbl_pass1->setGeometry(QRect(370, 360, 100, 20));
        lbl_pass1->setFont(font);
        lbl_pass1->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        txt_comfrim = new QLineEdit(SignUp);
        txt_comfrim->setObjectName(QString::fromUtf8("txt_comfrim"));
        txt_comfrim->setGeometry(QRect(370, 470, 250, 30));
        txt_comfrim->setFont(font1);
        txt_comfrim->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 133, 41);\n"
"color: rgb(78, 154, 6);"));
        txt_comfrim->setAlignment(Qt::AlignCenter);
        lbl_pass2 = new QLabel(SignUp);
        lbl_pass2->setObjectName(QString::fromUtf8("lbl_pass2"));
        lbl_pass2->setGeometry(QRect(370, 440, 151, 20));
        lbl_pass2->setFont(font);
        lbl_pass2->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        lbl_pass2_2 = new QLabel(SignUp);
        lbl_pass2_2->setObjectName(QString::fromUtf8("lbl_pass2_2"));
        lbl_pass2_2->setGeometry(QRect(370, 520, 151, 20));
        lbl_pass2_2->setFont(font);
        lbl_pass2_2->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        textEdit = new QTextEdit(SignUp);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(370, 550, 251, 131));
        textEdit->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 133, 41);\n"
"color: rgb(78, 154, 6);\n"
"\n"
""));
        btn_verify = new QPushButton(SignUp);
        btn_verify->setObjectName(QString::fromUtf8("btn_verify"));
        btn_verify->setGeometry(QRect(780, 510, 120, 30));
        btn_verify->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 113, 41);"));
        txt_month = new QLineEdit(SignUp);
        txt_month->setObjectName(QString::fromUtf8("txt_month"));
        txt_month->setGeometry(QRect(440, 70, 51, 30));
        txt_month->setFont(font1);
        txt_month->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 133, 41)"));
        txt_month->setAlignment(Qt::AlignCenter);
        lbl_slah = new QLabel(SignUp);
        lbl_slah->setObjectName(QString::fromUtf8("lbl_slah"));
        lbl_slah->setGeometry(QRect(425, 75, 16, 20));
        lbl_slah->setFont(font);
        lbl_slah->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        lbl_slah_2 = new QLabel(SignUp);
        lbl_slah_2->setObjectName(QString::fromUtf8("lbl_slah_2"));
        lbl_slah_2->setGeometry(QRect(495, 75, 16, 20));
        lbl_slah_2->setFont(font);
        lbl_slah_2->setStyleSheet(QString::fromUtf8("color: rgb(255, 113, 41);"));
        txt_day = new QLineEdit(SignUp);
        txt_day->setObjectName(QString::fromUtf8("txt_day"));
        txt_day->setGeometry(QRect(510, 70, 51, 30));
        txt_day->setFont(font1);
        txt_day->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 133, 41)"));
        txt_day->setAlignment(Qt::AlignCenter);
        QWidget::setTabOrder(radio_user, redio_employee);
        QWidget::setTabOrder(redio_employee, txt_national);
        QWidget::setTabOrder(txt_national, txt_name);
        QWidget::setTabOrder(txt_name, txt_lastname);
        QWidget::setTabOrder(txt_lastname, txt_email);
        QWidget::setTabOrder(txt_email, txt_mobile);
        QWidget::setTabOrder(txt_mobile, txt_home);
        QWidget::setTabOrder(txt_home, txt_day);
        QWidget::setTabOrder(txt_day, txt_month);
        QWidget::setTabOrder(txt_month, txt_year);
        QWidget::setTabOrder(txt_year, txt_city);
        QWidget::setTabOrder(txt_city, txt_post);
        QWidget::setTabOrder(txt_post, txt_user);
        QWidget::setTabOrder(txt_user, txt_pass);
        QWidget::setTabOrder(txt_pass, txt_comfrim);
        QWidget::setTabOrder(txt_comfrim, textEdit);
        QWidget::setTabOrder(textEdit, btn_load);
        QWidget::setTabOrder(btn_load, btn_close);
        QWidget::setTabOrder(btn_close, btn_clear);
        QWidget::setTabOrder(btn_clear, btn_cansel);
        QWidget::setTabOrder(btn_cansel, btn_verify);

        retranslateUi(SignUp);

        QMetaObject::connectSlotsByName(SignUp);
    } // setupUi

    void retranslateUi(QDialog *SignUp)
    {
        SignUp->setWindowTitle(QCoreApplication::translate("SignUp", "SignUp ...", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        lbl_firstname->setText(QCoreApplication::translate("SignUp", "Firstname* : ", nullptr));
        lbl_family->setText(QCoreApplication::translate("SignUp", "Lastname* :", nullptr));
        lbl_email->setText(QCoreApplication::translate("SignUp", "Email* :", nullptr));
        lbl_mobile->setText(QCoreApplication::translate("SignUp", "Mobile number* :", nullptr));
        lbl_home->setText(QCoreApplication::translate("SignUp", "Phone number :", nullptr));
        txt_year->setText(QString());
        lbl_birth->setText(QCoreApplication::translate("SignUp", "Birthdate* :", nullptr));
        lbl_national->setText(QCoreApplication::translate("SignUp", "National ID* :", nullptr));
        txt_national->setText(QString());
        gp_type->setTitle(QCoreApplication::translate("SignUp", "Type :", nullptr));
        radio_user->setText(QCoreApplication::translate("SignUp", "Normal User", nullptr));
        redio_employee->setText(QCoreApplication::translate("SignUp", "Employee", nullptr));
        pic_profile->setText(QString());
        btn_load->setText(QCoreApplication::translate("SignUp", "&Load", nullptr));
        btn_clear->setText(QCoreApplication::translate("SignUp", "&Clear", nullptr));
        btn_close->setText(QCoreApplication::translate("SignUp", "Cl&ose", nullptr));
        btn_cansel->setText(QCoreApplication::translate("SignUp", "C&ancel", nullptr));
        lbl_city->setText(QCoreApplication::translate("SignUp", "City :", nullptr));
        lbl_post->setText(QCoreApplication::translate("SignUp", "Postal Code :", nullptr));
        txt_user->setText(QString());
        lbl_user->setText(QCoreApplication::translate("SignUp", "Username* :", nullptr));
        lbl_pass1->setText(QCoreApplication::translate("SignUp", "Password* :", nullptr));
        lbl_pass2->setText(QCoreApplication::translate("SignUp", "Comfrim Password* :", nullptr));
        lbl_pass2_2->setText(QCoreApplication::translate("SignUp", "Address :", nullptr));
        btn_verify->setText(QCoreApplication::translate("SignUp", "&Verify", nullptr));
        txt_month->setText(QString());
        lbl_slah->setText(QCoreApplication::translate("SignUp", "/", nullptr));
        lbl_slah_2->setText(QCoreApplication::translate("SignUp", "/", nullptr));
        txt_day->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class SignUp: public Ui_SignUp {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SIGNUP_H
