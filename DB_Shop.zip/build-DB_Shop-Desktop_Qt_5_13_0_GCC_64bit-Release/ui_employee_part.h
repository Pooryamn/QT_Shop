/********************************************************************************
** Form generated from reading UI file 'employee_part.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EMPLOYEE_PART_H
#define UI_EMPLOYEE_PART_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_employee_part
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QPushButton *btn_resizer;
    QLabel *pic_2;
    QLineEdit *txt_search;
    QLabel *pic_5;
    QTableView *tbl_search;
    QLabel *pic_4;
    QGroupBox *GP_SearchMethod;
    QRadioButton *radio_Name;
    QRadioButton *redio_Category;
    QLabel *pic_1;
    QTextEdit *txt_description;
    QLabel *pic_0;
    QLabel *pic_3;
    QLabel *lbl_search;
    QLabel *pic_6;
    QLabel *lbl_line;
    QLabel *pic_profile;
    QPushButton *btn_addstock;
    QLabel *lbl_avalablity;
    QPushButton *btn_newstock;
    QPushButton *btn_logoff;
    QPushButton *btn_ediprofile;
    QPushButton *btn_payment;
    QLabel *lbl_firstname;
    QPushButton *btn_history;
    QLabel *lbl_lastname;
    QLabel *lbl_email;
    QLineEdit *txt_username;
    QLineEdit *txt_firstname;
    QLineEdit *txt_lastname;
    QLineEdit *txt_email;
    QSpinBox *spin_stock;

    void setupUi(QDialog *employee_part)
    {
        if (employee_part->objectName().isEmpty())
            employee_part->setObjectName(QString::fromUtf8("employee_part"));
        employee_part->resize(1280, 720);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Res/img/Logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        employee_part->setWindowIcon(icon);
        lbl_BG = new QLabel(employee_part);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 1280, 720));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(251, 234, 235);"));
        lbl_border = new QLabel(employee_part);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(15, 12, 1250, 695));
        lbl_border->setStyleSheet(QString::fromUtf8("border:5px solid rgb(47, 60, 126)"));
        btn_resizer = new QPushButton(employee_part);
        btn_resizer->setObjectName(QString::fromUtf8("btn_resizer"));
        btn_resizer->setGeometry(QRect(1255, 315, 15, 75));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        btn_resizer->setFont(font);
        pic_2 = new QLabel(employee_part);
        pic_2->setObjectName(QString::fromUtf8("pic_2"));
        pic_2->setGeometry(QRect(850, 230, 120, 120));
        pic_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 4px solid rgb(47, 60, 126);\n"
"\n"
""));
        pic_2->setAlignment(Qt::AlignCenter);
        txt_search = new QLineEdit(employee_part);
        txt_search->setObjectName(QString::fromUtf8("txt_search"));
        txt_search->setGeometry(QRect(30, 45, 250, 30));
        txt_search->setStyleSheet(QString::fromUtf8("border:4px solid rgb(47, 60, 126);\n"
"color: rgb(47, 0, 255);"));
        pic_5 = new QLabel(employee_part);
        pic_5->setObjectName(QString::fromUtf8("pic_5"));
        pic_5->setGeometry(QRect(720, 370, 120, 120));
        pic_5->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 4px solid rgb(47, 60, 126);\n"
""));
        pic_5->setAlignment(Qt::AlignCenter);
        tbl_search = new QTableView(employee_part);
        tbl_search->setObjectName(QString::fromUtf8("tbl_search"));
        tbl_search->setGeometry(QRect(30, 170, 250, 521));
        tbl_search->setStyleSheet(QString::fromUtf8(""));
        pic_4 = new QLabel(employee_part);
        pic_4->setObjectName(QString::fromUtf8("pic_4"));
        pic_4->setGeometry(QRect(720, 230, 120, 120));
        pic_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 4px solid rgb(47, 60, 126);\n"
""));
        pic_4->setAlignment(Qt::AlignCenter);
        GP_SearchMethod = new QGroupBox(employee_part);
        GP_SearchMethod->setObjectName(QString::fromUtf8("GP_SearchMethod"));
        GP_SearchMethod->setGeometry(QRect(30, 80, 250, 80));
        QFont font1;
        font1.setBold(true);
        font1.setWeight(75);
        GP_SearchMethod->setFont(font1);
        GP_SearchMethod->setStyleSheet(QString::fromUtf8("color: rgb(47, 60, 126);"));
        radio_Name = new QRadioButton(GP_SearchMethod);
        radio_Name->setObjectName(QString::fromUtf8("radio_Name"));
        radio_Name->setGeometry(QRect(10, 25, 112, 23));
        QFont font2;
        font2.setPointSize(13);
        font2.setBold(true);
        font2.setWeight(75);
        radio_Name->setFont(font2);
        radio_Name->setChecked(true);
        redio_Category = new QRadioButton(GP_SearchMethod);
        redio_Category->setObjectName(QString::fromUtf8("redio_Category"));
        redio_Category->setGeometry(QRect(10, 50, 112, 23));
        redio_Category->setFont(font2);
        pic_1 = new QLabel(employee_part);
        pic_1->setObjectName(QString::fromUtf8("pic_1"));
        pic_1->setGeometry(QRect(850, 90, 120, 120));
        pic_1->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 4px solid rgb(47, 60, 126);\n"
"\n"
"\n"
"\n"
""));
        pic_1->setAlignment(Qt::AlignCenter);
        txt_description = new QTextEdit(employee_part);
        txt_description->setObjectName(QString::fromUtf8("txt_description"));
        txt_description->setGeometry(QRect(310, 500, 661, 191));
        txt_description->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"\n"
""));
        pic_0 = new QLabel(employee_part);
        pic_0->setObjectName(QString::fromUtf8("pic_0"));
        pic_0->setGeometry(QRect(310, 90, 400, 400));
        pic_0->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 5px solid rgb(47, 60, 126);\n"
"\n"
"\n"
""));
        pic_0->setAlignment(Qt::AlignCenter);
        pic_3 = new QLabel(employee_part);
        pic_3->setObjectName(QString::fromUtf8("pic_3"));
        pic_3->setGeometry(QRect(850, 370, 120, 120));
        pic_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 4px solid rgb(47, 60, 126);\n"
""));
        pic_3->setAlignment(Qt::AlignCenter);
        lbl_search = new QLabel(employee_part);
        lbl_search->setObjectName(QString::fromUtf8("lbl_search"));
        lbl_search->setGeometry(QRect(30, 20, 71, 20));
        lbl_search->setFont(font2);
        lbl_search->setStyleSheet(QString::fromUtf8("color: rgb(47, 60, 126);\n"
""));
        pic_6 = new QLabel(employee_part);
        pic_6->setObjectName(QString::fromUtf8("pic_6"));
        pic_6->setGeometry(QRect(720, 90, 120, 120));
        pic_6->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 4px solid rgb(47, 60, 126);\n"
"\n"
""));
        pic_6->setAlignment(Qt::AlignCenter);
        lbl_line = new QLabel(employee_part);
        lbl_line->setObjectName(QString::fromUtf8("lbl_line"));
        lbl_line->setGeometry(QRect(980, 15, 5, 690));
        lbl_line->setStyleSheet(QString::fromUtf8("border:5px solid rgb(47, 60, 126);"));
        pic_profile = new QLabel(employee_part);
        pic_profile->setObjectName(QString::fromUtf8("pic_profile"));
        pic_profile->setGeometry(QRect(1130, 90, 120, 150));
        pic_profile->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(47, 60, 126);\n"
"background-color: rgb(255, 255, 255);"));
        btn_addstock = new QPushButton(employee_part);
        btn_addstock->setObjectName(QString::fromUtf8("btn_addstock"));
        btn_addstock->setGeometry(QRect(310, 45, 120, 30));
        btn_addstock->setFont(font);
        btn_addstock->setStyleSheet(QString::fromUtf8("background-color: rgb(47, 60, 126);\n"
"color: rgb(251, 234, 235);"));
        lbl_avalablity = new QLabel(employee_part);
        lbl_avalablity->setObjectName(QString::fromUtf8("lbl_avalablity"));
        lbl_avalablity->setGeometry(QRect(749, 30, 171, 45));
        QFont font3;
        font3.setPointSize(19);
        font3.setBold(true);
        font3.setWeight(75);
        lbl_avalablity->setFont(font3);
        lbl_avalablity->setStyleSheet(QString::fromUtf8(""));
        lbl_avalablity->setAlignment(Qt::AlignCenter);
        btn_newstock = new QPushButton(employee_part);
        btn_newstock->setObjectName(QString::fromUtf8("btn_newstock"));
        btn_newstock->setGeometry(QRect(1000, 90, 120, 30));
        btn_newstock->setFont(font);
        btn_newstock->setStyleSheet(QString::fromUtf8("background-color: rgb(47, 60, 126);\n"
"color: rgb(251, 234, 235);"));
        btn_logoff = new QPushButton(employee_part);
        btn_logoff->setObjectName(QString::fromUtf8("btn_logoff"));
        btn_logoff->setGeometry(QRect(1130, 660, 120, 30));
        btn_logoff->setFont(font);
        btn_logoff->setStyleSheet(QString::fromUtf8("background-color: rgb(47, 60, 126);\n"
"color: rgb(251, 234, 235);"));
        btn_ediprofile = new QPushButton(employee_part);
        btn_ediprofile->setObjectName(QString::fromUtf8("btn_ediprofile"));
        btn_ediprofile->setGeometry(QRect(1000, 130, 120, 30));
        btn_ediprofile->setFont(font);
        btn_ediprofile->setStyleSheet(QString::fromUtf8("background-color: rgb(47, 60, 126);\n"
"color: rgb(251, 234, 235);"));
        btn_payment = new QPushButton(employee_part);
        btn_payment->setObjectName(QString::fromUtf8("btn_payment"));
        btn_payment->setGeometry(QRect(1000, 170, 120, 30));
        btn_payment->setFont(font);
        btn_payment->setStyleSheet(QString::fromUtf8("background-color: rgb(47, 60, 126);\n"
"color: rgb(251, 234, 235);"));
        lbl_firstname = new QLabel(employee_part);
        lbl_firstname->setObjectName(QString::fromUtf8("lbl_firstname"));
        lbl_firstname->setGeometry(QRect(1000, 360, 151, 31));
        lbl_firstname->setFont(font);
        lbl_firstname->setStyleSheet(QString::fromUtf8("color: rgb(47, 60, 126);"));
        btn_history = new QPushButton(employee_part);
        btn_history->setObjectName(QString::fromUtf8("btn_history"));
        btn_history->setGeometry(QRect(1000, 210, 120, 30));
        btn_history->setFont(font);
        btn_history->setStyleSheet(QString::fromUtf8("background-color: rgb(47, 60, 126);\n"
"color: rgb(251, 234, 235);"));
        lbl_lastname = new QLabel(employee_part);
        lbl_lastname->setObjectName(QString::fromUtf8("lbl_lastname"));
        lbl_lastname->setGeometry(QRect(1000, 450, 151, 31));
        lbl_lastname->setFont(font);
        lbl_lastname->setStyleSheet(QString::fromUtf8("color: rgb(47, 60, 126);"));
        lbl_email = new QLabel(employee_part);
        lbl_email->setObjectName(QString::fromUtf8("lbl_email"));
        lbl_email->setGeometry(QRect(1000, 540, 151, 31));
        lbl_email->setFont(font);
        lbl_email->setStyleSheet(QString::fromUtf8("color: rgb(47, 60, 126);"));
        txt_username = new QLineEdit(employee_part);
        txt_username->setObjectName(QString::fromUtf8("txt_username"));
        txt_username->setGeometry(QRect(1000, 30, 250, 45));
        QFont font4;
        font4.setPointSize(18);
        font4.setBold(true);
        font4.setWeight(75);
        txt_username->setFont(font4);
        txt_username->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(47, 60, 126);"));
        txt_username->setAlignment(Qt::AlignCenter);
        txt_firstname = new QLineEdit(employee_part);
        txt_firstname->setObjectName(QString::fromUtf8("txt_firstname"));
        txt_firstname->setGeometry(QRect(1000, 390, 230, 45));
        txt_firstname->setFont(font4);
        txt_firstname->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(47, 60, 126);"));
        txt_firstname->setAlignment(Qt::AlignCenter);
        txt_lastname = new QLineEdit(employee_part);
        txt_lastname->setObjectName(QString::fromUtf8("txt_lastname"));
        txt_lastname->setGeometry(QRect(1000, 480, 230, 45));
        txt_lastname->setFont(font4);
        txt_lastname->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(47, 60, 126);"));
        txt_lastname->setAlignment(Qt::AlignCenter);
        txt_email = new QLineEdit(employee_part);
        txt_email->setObjectName(QString::fromUtf8("txt_email"));
        txt_email->setGeometry(QRect(1000, 570, 230, 45));
        txt_email->setFont(font4);
        txt_email->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(47, 60, 126);"));
        txt_email->setAlignment(Qt::AlignCenter);
        spin_stock = new QSpinBox(employee_part);
        spin_stock->setObjectName(QString::fromUtf8("spin_stock"));
        spin_stock->setGeometry(QRect(440, 42, 48, 34));
        lbl_BG->raise();
        lbl_border->raise();
        lbl_line->raise();
        btn_resizer->raise();
        pic_2->raise();
        txt_search->raise();
        pic_5->raise();
        tbl_search->raise();
        pic_4->raise();
        GP_SearchMethod->raise();
        pic_1->raise();
        txt_description->raise();
        pic_0->raise();
        pic_3->raise();
        lbl_search->raise();
        pic_6->raise();
        pic_profile->raise();
        btn_addstock->raise();
        lbl_avalablity->raise();
        btn_newstock->raise();
        btn_logoff->raise();
        btn_ediprofile->raise();
        btn_payment->raise();
        lbl_firstname->raise();
        btn_history->raise();
        lbl_lastname->raise();
        lbl_email->raise();
        txt_username->raise();
        txt_firstname->raise();
        txt_lastname->raise();
        txt_email->raise();
        spin_stock->raise();

        retranslateUi(employee_part);

        QMetaObject::connectSlotsByName(employee_part);
    } // setupUi

    void retranslateUi(QDialog *employee_part)
    {
        employee_part->setWindowTitle(QCoreApplication::translate("employee_part", "Account", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        btn_resizer->setText(QCoreApplication::translate("employee_part", "<", nullptr));
        pic_2->setText(QString());
        pic_5->setText(QString());
        pic_4->setText(QString());
        GP_SearchMethod->setTitle(QCoreApplication::translate("employee_part", "Search by :", nullptr));
        radio_Name->setText(QCoreApplication::translate("employee_part", "Name", nullptr));
        redio_Category->setText(QCoreApplication::translate("employee_part", "Category", nullptr));
        pic_1->setText(QString());
        pic_0->setText(QString());
        pic_3->setText(QString());
        lbl_search->setText(QCoreApplication::translate("employee_part", "Search :", nullptr));
        pic_6->setText(QString());
        lbl_line->setText(QString());
        pic_profile->setText(QString());
        btn_addstock->setText(QCoreApplication::translate("employee_part", "+ &Add Stock", nullptr));
        lbl_avalablity->setText(QCoreApplication::translate("employee_part", "Not Available", nullptr));
        btn_newstock->setText(QCoreApplication::translate("employee_part", "+ New Stock", nullptr));
        btn_logoff->setText(QCoreApplication::translate("employee_part", "&Log off", nullptr));
        btn_ediprofile->setText(QCoreApplication::translate("employee_part", "&Edit Profile", nullptr));
        btn_payment->setText(QCoreApplication::translate("employee_part", "&Payments", nullptr));
        lbl_firstname->setText(QCoreApplication::translate("employee_part", "Firstname :", nullptr));
        btn_history->setText(QCoreApplication::translate("employee_part", "&Shop History", nullptr));
        lbl_lastname->setText(QCoreApplication::translate("employee_part", "Lastname :", nullptr));
        lbl_email->setText(QCoreApplication::translate("employee_part", "Email :", nullptr));
        txt_username->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class employee_part: public Ui_employee_part {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EMPLOYEE_PART_H
