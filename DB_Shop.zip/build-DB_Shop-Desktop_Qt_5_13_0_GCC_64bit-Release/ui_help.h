/********************************************************************************
** Form generated from reading UI file 'help.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HELP_H
#define UI_HELP_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Help
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QLabel *label;
    QLabel *label_4;
    QLabel *pic_programmer;
    QLabel *pic_telegram;
    QLabel *pic_email2;
    QLabel *pic_email1;
    QLabel *pic_phone;
    QLabel *pic_git;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;

    void setupUi(QDialog *Help)
    {
        if (Help->objectName().isEmpty())
            Help->setObjectName(QString::fromUtf8("Help"));
        Help->resize(800, 600);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Res/img/Help.png"), QSize(), QIcon::Normal, QIcon::Off);
        Help->setWindowIcon(icon);
        lbl_BG = new QLabel(Help);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 800, 600));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(91, 14, 45);"));
        lbl_border = new QLabel(Help);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(15, 15, 770, 570));
        QFont font;
        font.setPointSize(24);
        font.setBold(true);
        font.setUnderline(false);
        font.setWeight(75);
        lbl_border->setFont(font);
        lbl_border->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(255, 167, 129);"));
        label = new QLabel(Help);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(140, 70, 311, 50));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Ubuntu Condensed"));
        font1.setPointSize(18);
        font1.setBold(false);
        font1.setItalic(true);
        font1.setWeight(9);
        label->setFont(font1);
        label->setStyleSheet(QString::fromUtf8("font: 75 italic 18pt \"Ubuntu Condensed\";\n"
"color: rgb(255, 167, 129);"));
        label_4 = new QLabel(Help);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(140, 210, 311, 51));
        label_4->setFont(font1);
        label_4->setStyleSheet(QString::fromUtf8("font: 75 italic 18pt \"Ubuntu Condensed\";\n"
"color: rgb(255, 167, 129);"));
        pic_programmer = new QLabel(Help);
        pic_programmer->setObjectName(QString::fromUtf8("pic_programmer"));
        pic_programmer->setGeometry(QRect(50, 50, 70, 70));
        pic_programmer->setAlignment(Qt::AlignCenter);
        pic_telegram = new QLabel(Help);
        pic_telegram->setObjectName(QString::fromUtf8("pic_telegram"));
        pic_telegram->setGeometry(QRect(50, 360, 70, 70));
        pic_telegram->setAlignment(Qt::AlignCenter);
        pic_email2 = new QLabel(Help);
        pic_email2->setObjectName(QString::fromUtf8("pic_email2"));
        pic_email2->setGeometry(QRect(50, 280, 70, 70));
        pic_email2->setAlignment(Qt::AlignCenter);
        pic_email1 = new QLabel(Help);
        pic_email1->setObjectName(QString::fromUtf8("pic_email1"));
        pic_email1->setGeometry(QRect(50, 200, 70, 70));
        pic_email1->setAlignment(Qt::AlignCenter);
        pic_phone = new QLabel(Help);
        pic_phone->setObjectName(QString::fromUtf8("pic_phone"));
        pic_phone->setGeometry(QRect(50, 120, 70, 70));
        pic_phone->setAlignment(Qt::AlignCenter);
        pic_git = new QLabel(Help);
        pic_git->setObjectName(QString::fromUtf8("pic_git"));
        pic_git->setGeometry(QRect(50, 440, 70, 70));
        pic_git->setAlignment(Qt::AlignCenter);
        label_5 = new QLabel(Help);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(140, 290, 311, 51));
        label_5->setFont(font1);
        label_5->setStyleSheet(QString::fromUtf8("font: 75 italic 18pt \"Ubuntu Condensed\";\n"
"color: rgb(255, 167, 129);"));
        label_6 = new QLabel(Help);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(140, 370, 311, 51));
        label_6->setFont(font1);
        label_6->setStyleSheet(QString::fromUtf8("font: 75 italic 18pt \"Ubuntu Condensed\";\n"
"color: rgb(255, 167, 129);"));
        label_7 = new QLabel(Help);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(140, 445, 311, 51));
        label_7->setFont(font1);
        label_7->setStyleSheet(QString::fromUtf8("font: 75 italic 18pt \"Ubuntu Condensed\";\n"
"color: rgb(255, 167, 129);"));
        label_8 = new QLabel(Help);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(140, 130, 311, 51));
        label_8->setFont(font1);
        label_8->setStyleSheet(QString::fromUtf8("font: 75 italic 18pt \"Ubuntu Condensed\";\n"
"color: rgb(255, 167, 129);"));

        retranslateUi(Help);

        QMetaObject::connectSlotsByName(Help);
    } // setupUi

    void retranslateUi(QDialog *Help)
    {
        Help->setWindowTitle(QCoreApplication::translate("Help", "Help", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        label->setText(QCoreApplication::translate("Help", "Poorya Mohammadi Nasab", nullptr));
        label_4->setText(QCoreApplication::translate("Help", "Poorya.m.n.b@gmail.com", nullptr));
        pic_programmer->setText(QString());
        pic_telegram->setText(QString());
        pic_email2->setText(QString());
        pic_email1->setText(QString());
        pic_phone->setText(QString());
        pic_git->setText(QString());
        label_5->setText(QCoreApplication::translate("Help", "Poorya@gmx.com", nullptr));
        label_6->setText(QCoreApplication::translate("Help", "t.me/@P_M_N", nullptr));
        label_7->setText(QCoreApplication::translate("Help", "github.com/Pooryamn", nullptr));
        label_8->setText(QCoreApplication::translate("Help", "+98 913 630 7782", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Help: public Ui_Help {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HELP_H
