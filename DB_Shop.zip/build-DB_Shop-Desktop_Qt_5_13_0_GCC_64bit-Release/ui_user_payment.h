/********************************************************************************
** Form generated from reading UI file 'user_payment.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USER_PAYMENT_H
#define UI_USER_PAYMENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_user_payment
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QTableView *tbl_payment;
    QPushButton *btn_addpayment;

    void setupUi(QDialog *user_payment)
    {
        if (user_payment->objectName().isEmpty())
            user_payment->setObjectName(QString::fromUtf8("user_payment"));
        user_payment->resize(1000, 600);
        lbl_BG = new QLabel(user_payment);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 1000, 600));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(53, 133, 151);"));
        lbl_border = new QLabel(user_payment);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(15, 15, 970, 570));
        lbl_border->setStyleSheet(QString::fromUtf8("border:5px solid rgb(244, 168, 150)"));
        tbl_payment = new QTableView(user_payment);
        tbl_payment->setObjectName(QString::fromUtf8("tbl_payment"));
        tbl_payment->setGeometry(QRect(40, 85, 920, 480));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        tbl_payment->setFont(font);
        tbl_payment->setStyleSheet(QString::fromUtf8(""));
        btn_addpayment = new QPushButton(user_payment);
        btn_addpayment->setObjectName(QString::fromUtf8("btn_addpayment"));
        btn_addpayment->setGeometry(QRect(40, 40, 35, 35));
        QFont font1;
        font1.setPointSize(17);
        font1.setBold(true);
        font1.setWeight(75);
        btn_addpayment->setFont(font1);
        btn_addpayment->setStyleSheet(QString::fromUtf8("background-color: rgb(78, 154, 6);\n"
"color: rgb(255, 255, 255);"));

        retranslateUi(user_payment);

        QMetaObject::connectSlotsByName(user_payment);
    } // setupUi

    void retranslateUi(QDialog *user_payment)
    {
        user_payment->setWindowTitle(QCoreApplication::translate("user_payment", "Payments ", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        btn_addpayment->setText(QCoreApplication::translate("user_payment", "+", nullptr));
    } // retranslateUi

};

namespace Ui {
    class user_payment: public Ui_user_payment {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USER_PAYMENT_H
