/********************************************************************************
** Form generated from reading UI file 'gateway.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GATEWAY_H
#define UI_GATEWAY_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_gateway
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QLabel *lbl_amount;
    QLineEdit *txt_amount;
    QPushButton *btn_cancel;
    QPushButton *btn_pay;

    void setupUi(QDialog *gateway)
    {
        if (gateway->objectName().isEmpty())
            gateway->setObjectName(QString::fromUtf8("gateway"));
        gateway->resize(600, 400);
        lbl_BG = new QLabel(gateway);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 600, 400));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(251, 234, 235);"));
        lbl_border = new QLabel(gateway);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(15, 15, 570, 370));
        lbl_border->setStyleSheet(QString::fromUtf8("border:5px solid rgb(91, 14, 45);"));
        lbl_amount = new QLabel(gateway);
        lbl_amount->setObjectName(QString::fromUtf8("lbl_amount"));
        lbl_amount->setGeometry(QRect(150, 110, 311, 30));
        QFont font;
        font.setPointSize(20);
        font.setBold(true);
        font.setWeight(75);
        lbl_amount->setFont(font);
        lbl_amount->setStyleSheet(QString::fromUtf8("color: rgb(91, 14, 45);"));
        txt_amount = new QLineEdit(gateway);
        txt_amount->setObjectName(QString::fromUtf8("txt_amount"));
        txt_amount->setGeometry(QRect(120, 150, 360, 45));
        QFont font1;
        font1.setPointSize(18);
        font1.setBold(true);
        font1.setWeight(75);
        txt_amount->setFont(font1);
        txt_amount->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(91, 14, 45);\n"
"color: rgb(91, 14, 45);;"));
        txt_amount->setAlignment(Qt::AlignCenter);
        btn_cancel = new QPushButton(gateway);
        btn_cancel->setObjectName(QString::fromUtf8("btn_cancel"));
        btn_cancel->setGeometry(QRect(250, 290, 100, 40));
        QFont font2;
        font2.setPointSize(17);
        font2.setBold(true);
        font2.setWeight(75);
        font2.setKerning(true);
        btn_cancel->setFont(font2);
        btn_cancel->setStyleSheet(QString::fromUtf8("background-color: rgb(91, 14, 45);\n"
"color: rgb(251, 234, 235);\n"
""));
        btn_pay = new QPushButton(gateway);
        btn_pay->setObjectName(QString::fromUtf8("btn_pay"));
        btn_pay->setGeometry(QRect(200, 240, 200, 40));
        QFont font3;
        font3.setPointSize(17);
        font3.setBold(true);
        font3.setWeight(75);
        btn_pay->setFont(font3);
        btn_pay->setStyleSheet(QString::fromUtf8("background-color: rgb(91, 14, 45);\n"
"color: rgb(251, 234, 235);\n"
""));
        QWidget::setTabOrder(txt_amount, btn_pay);
        QWidget::setTabOrder(btn_pay, btn_cancel);

        retranslateUi(gateway);

        QMetaObject::connectSlotsByName(gateway);
    } // setupUi

    void retranslateUi(QDialog *gateway)
    {
        gateway->setWindowTitle(QCoreApplication::translate("gateway", "Payment Gateway", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        lbl_amount->setText(QCoreApplication::translate("gateway", "Diposit Amount (Rials) :", nullptr));
        txt_amount->setText(QString());
        btn_cancel->setText(QCoreApplication::translate("gateway", "Cancel", nullptr));
        btn_pay->setText(QCoreApplication::translate("gateway", "Pay", nullptr));
    } // retranslateUi

};

namespace Ui {
    class gateway: public Ui_gateway {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GATEWAY_H
