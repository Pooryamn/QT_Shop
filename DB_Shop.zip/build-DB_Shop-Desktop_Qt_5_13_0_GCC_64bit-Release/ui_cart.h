/********************************************************************************
** Form generated from reading UI file 'cart.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CART_H
#define UI_CART_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_Cart
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QTableView *tbl_cart;
    QPushButton *btn_pay;
    QLineEdit *txt_total;
    QLabel *lbl_total;
    QPushButton *btn_delete;

    void setupUi(QDialog *Cart)
    {
        if (Cart->objectName().isEmpty())
            Cart->setObjectName(QString::fromUtf8("Cart"));
        Cart->resize(1000, 600);
        lbl_BG = new QLabel(Cart);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 1000, 600));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(53, 133, 151);"));
        lbl_border = new QLabel(Cart);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(15, 15, 970, 570));
        lbl_border->setStyleSheet(QString::fromUtf8("border:5px solid rgb(244, 168, 150)"));
        tbl_cart = new QTableView(Cart);
        tbl_cart->setObjectName(QString::fromUtf8("tbl_cart"));
        tbl_cart->setGeometry(QRect(40, 40, 920, 430));
        tbl_cart->setStyleSheet(QString::fromUtf8(""));
        tbl_cart->verticalHeader()->setVisible(false);
        tbl_cart->verticalHeader()->setMinimumSectionSize(20);
        tbl_cart->verticalHeader()->setDefaultSectionSize(30);
        btn_pay = new QPushButton(Cart);
        btn_pay->setObjectName(QString::fromUtf8("btn_pay"));
        btn_pay->setGeometry(QRect(30, 540, 100, 30));
        QFont font;
        font.setPointSize(13);
        font.setBold(true);
        font.setWeight(75);
        btn_pay->setFont(font);
        btn_pay->setStyleSheet(QString::fromUtf8("background-color: rgb(244, 168, 150);\n"
"color: rgb(53, 133, 151);"));
        txt_total = new QLineEdit(Cart);
        txt_total->setObjectName(QString::fromUtf8("txt_total"));
        txt_total->setGeometry(QRect(760, 485, 200, 35));
        QFont font1;
        font1.setPointSize(10);
        txt_total->setFont(font1);
        txt_total->setStyleSheet(QString::fromUtf8("border:4px solid rgb(244, 168, 150)"));
        txt_total->setAlignment(Qt::AlignCenter);
        lbl_total = new QLabel(Cart);
        lbl_total->setObjectName(QString::fromUtf8("lbl_total"));
        lbl_total->setGeometry(QRect(690, 490, 61, 21));
        QFont font2;
        font2.setPointSize(14);
        font2.setBold(true);
        font2.setWeight(75);
        lbl_total->setFont(font2);
        lbl_total->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150);"));
        btn_delete = new QPushButton(Cart);
        btn_delete->setObjectName(QString::fromUtf8("btn_delete"));
        btn_delete->setGeometry(QRect(40, 480, 35, 35));
        QFont font3;
        font3.setPointSize(21);
        font3.setBold(true);
        font3.setWeight(75);
        btn_delete->setFont(font3);
        btn_delete->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);\n"
"color: rgb(255, 255, 255);"));

        retranslateUi(Cart);

        QMetaObject::connectSlotsByName(Cart);
    } // setupUi

    void retranslateUi(QDialog *Cart)
    {
        Cart->setWindowTitle(QCoreApplication::translate("Cart", "Cart", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        btn_pay->setText(QCoreApplication::translate("Cart", "&Pay it", nullptr));
        lbl_total->setText(QCoreApplication::translate("Cart", "Total :", nullptr));
        btn_delete->setText(QCoreApplication::translate("Cart", "-", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Cart: public Ui_Cart {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CART_H
