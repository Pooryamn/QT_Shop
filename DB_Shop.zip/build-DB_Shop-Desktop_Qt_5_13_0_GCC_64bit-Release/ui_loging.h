/********************************************************************************
** Form generated from reading UI file 'loging.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGING_H
#define UI_LOGING_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Loging
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QLabel *lbl_user;
    QLineEdit *txt_User;
    QLabel *lbl_pass;
    QLineEdit *txt_password;
    QPushButton *btn_login;
    QPushButton *btn_forget;
    QPushButton *btn_cancel;

    void setupUi(QDialog *Loging)
    {
        if (Loging->objectName().isEmpty())
            Loging->setObjectName(QString::fromUtf8("Loging"));
        Loging->resize(800, 600);
        lbl_BG = new QLabel(Loging);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 800, 600));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(91, 14, 45);"));
        lbl_border = new QLabel(Loging);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(15, 15, 770, 570));
        lbl_border->setStyleSheet(QString::fromUtf8("border:5px solid rgb(255,167,129);"));
        lbl_border->setInputMethodHints(Qt::ImhNone);
        lbl_user = new QLabel(Loging);
        lbl_user->setObjectName(QString::fromUtf8("lbl_user"));
        lbl_user->setGeometry(QRect(350, 140, 100, 50));
        QFont font;
        font.setFamily(QString::fromUtf8("Ubuntu Condensed"));
        font.setPointSize(18);
        font.setBold(false);
        font.setItalic(true);
        font.setWeight(9);
        lbl_user->setFont(font);
        lbl_user->setStyleSheet(QString::fromUtf8("font: 75 italic 18pt \"Ubuntu Condensed\";\n"
"color: rgb(255, 167, 129);"));
        txt_User = new QLineEdit(Loging);
        txt_User->setObjectName(QString::fromUtf8("txt_User"));
        txt_User->setGeometry(QRect(275, 200, 250, 35));
        QFont font1;
        font1.setPointSize(15);
        font1.setBold(true);
        font1.setWeight(75);
        txt_User->setFont(font1);
        txt_User->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(255,167,129);\n"
"color: rgb(47, 60, 126);"));
        txt_User->setAlignment(Qt::AlignCenter);
        lbl_pass = new QLabel(Loging);
        lbl_pass->setObjectName(QString::fromUtf8("lbl_pass"));
        lbl_pass->setGeometry(QRect(350, 240, 100, 50));
        lbl_pass->setFont(font);
        lbl_pass->setStyleSheet(QString::fromUtf8("font: 75 italic 18pt \"Ubuntu Condensed\";\n"
"color: rgb(255, 167, 129);"));
        txt_password = new QLineEdit(Loging);
        txt_password->setObjectName(QString::fromUtf8("txt_password"));
        txt_password->setGeometry(QRect(275, 300, 250, 35));
        QFont font2;
        font2.setPointSize(17);
        txt_password->setFont(font2);
        txt_password->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(255,167,129);\n"
"color: rgb(47, 60, 126);"));
        txt_password->setInputMethodHints(Qt::ImhHiddenText|Qt::ImhNoAutoUppercase|Qt::ImhNoPredictiveText|Qt::ImhSensitiveData);
        txt_password->setEchoMode(QLineEdit::Password);
        txt_password->setAlignment(Qt::AlignCenter);
        btn_login = new QPushButton(Loging);
        btn_login->setObjectName(QString::fromUtf8("btn_login"));
        btn_login->setGeometry(QRect(350, 360, 100, 30));
        QFont font3;
        font3.setPointSize(13);
        font3.setBold(true);
        font3.setWeight(75);
        btn_login->setFont(font3);
        btn_login->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 167, 129);\n"
"color: rgb(91, 14, 45);"));
        btn_forget = new QPushButton(Loging);
        btn_forget->setObjectName(QString::fromUtf8("btn_forget"));
        btn_forget->setGeometry(QRect(300, 530, 200, 30));
        btn_forget->setFont(font3);
        btn_forget->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 167, 129);\n"
"color: rgb(91, 14, 45);"));
        btn_cancel = new QPushButton(Loging);
        btn_cancel->setObjectName(QString::fromUtf8("btn_cancel"));
        btn_cancel->setGeometry(QRect(350, 400, 100, 30));
        btn_cancel->setFont(font3);
        btn_cancel->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 167, 129);\n"
"color: rgb(91, 14, 45);"));
        QWidget::setTabOrder(txt_User, txt_password);
        QWidget::setTabOrder(txt_password, btn_login);
        QWidget::setTabOrder(btn_login, btn_cancel);
        QWidget::setTabOrder(btn_cancel, btn_forget);

        retranslateUi(Loging);

        QMetaObject::connectSlotsByName(Loging);
    } // setupUi

    void retranslateUi(QDialog *Loging)
    {
        Loging->setWindowTitle(QCoreApplication::translate("Loging", "Login ...", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        lbl_user->setText(QCoreApplication::translate("Loging", "Username :", nullptr));
        txt_User->setText(QString());
        lbl_pass->setText(QCoreApplication::translate("Loging", "Password :", nullptr));
        txt_password->setText(QString());
        btn_login->setText(QCoreApplication::translate("Loging", "&Login", nullptr));
        btn_forget->setText(QCoreApplication::translate("Loging", "&Forget Passwod", nullptr));
        btn_cancel->setText(QCoreApplication::translate("Loging", "&Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Loging: public Ui_Loging {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGING_H
