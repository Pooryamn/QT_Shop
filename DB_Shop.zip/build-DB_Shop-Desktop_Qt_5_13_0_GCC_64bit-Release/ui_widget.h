/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QLabel *lbl_border;
    QLabel *lbl_search;
    QLineEdit *txt_search;
    QGroupBox *GP_SearchMethod;
    QRadioButton *radio_Name;
    QRadioButton *redio_Category;
    QTableView *tbl_search;
    QLabel *pic_0;
    QPushButton *btn_register;
    QPushButton *btn_login;
    QPushButton *btn_help;
    QTextEdit *txt_description;
    QLabel *lbl_BG;
    QLabel *lbl_warning;
    QPushButton *pic_1;
    QPushButton *pic_2;
    QPushButton *pic_3;
    QPushButton *pic_4;
    QPushButton *pic_5;
    QPushButton *pic_6;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(1000, 720);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Res/img/Logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        Widget->setWindowIcon(icon);
        lbl_border = new QLabel(Widget);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(10, 10, 980, 700));
        lbl_border->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(255, 255, 255);"));
        lbl_search = new QLabel(Widget);
        lbl_search->setObjectName(QString::fromUtf8("lbl_search"));
        lbl_search->setGeometry(QRect(30, 30, 71, 20));
        QFont font;
        font.setPointSize(13);
        font.setBold(true);
        font.setWeight(75);
        lbl_search->setFont(font);
        lbl_search->setStyleSheet(QString::fromUtf8("color: rgb(91,14,45);\n"
""));
        txt_search = new QLineEdit(Widget);
        txt_search->setObjectName(QString::fromUtf8("txt_search"));
        txt_search->setGeometry(QRect(30, 55, 250, 30));
        txt_search->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(91,14,45);\n"
"color: rgb(47, 0, 255);"));
        GP_SearchMethod = new QGroupBox(Widget);
        GP_SearchMethod->setObjectName(QString::fromUtf8("GP_SearchMethod"));
        GP_SearchMethod->setGeometry(QRect(30, 90, 250, 80));
        QFont font1;
        font1.setBold(true);
        font1.setWeight(75);
        GP_SearchMethod->setFont(font1);
        GP_SearchMethod->setStyleSheet(QString::fromUtf8("color: rgb(91,14,45);"));
        radio_Name = new QRadioButton(GP_SearchMethod);
        radio_Name->setObjectName(QString::fromUtf8("radio_Name"));
        radio_Name->setGeometry(QRect(10, 25, 112, 23));
        radio_Name->setFont(font);
        radio_Name->setChecked(true);
        redio_Category = new QRadioButton(GP_SearchMethod);
        redio_Category->setObjectName(QString::fromUtf8("redio_Category"));
        redio_Category->setGeometry(QRect(10, 50, 112, 23));
        redio_Category->setFont(font);
        tbl_search = new QTableView(Widget);
        tbl_search->setObjectName(QString::fromUtf8("tbl_search"));
        tbl_search->setGeometry(QRect(30, 180, 250, 521));
        tbl_search->setStyleSheet(QString::fromUtf8(""));
        tbl_search->verticalHeader()->setVisible(false);
        pic_0 = new QLabel(Widget);
        pic_0->setObjectName(QString::fromUtf8("pic_0"));
        pic_0->setGeometry(QRect(310, 100, 400, 400));
        pic_0->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 5px solid rgb(91,14,45);\n"
"\n"
"\n"
""));
        pic_0->setAlignment(Qt::AlignCenter);
        btn_register = new QPushButton(Widget);
        btn_register->setObjectName(QString::fromUtf8("btn_register"));
        btn_register->setGeometry(QRect(870, 20, 100, 30));
        QFont font2;
        font2.setPointSize(12);
        font2.setBold(true);
        font2.setWeight(75);
        btn_register->setFont(font2);
        btn_register->setStyleSheet(QString::fromUtf8("color: rgb(255,167,129);\n"
"background-color: rgb(91,14,45);\n"
""));
        btn_login = new QPushButton(Widget);
        btn_login->setObjectName(QString::fromUtf8("btn_login"));
        btn_login->setGeometry(QRect(760, 20, 100, 30));
        btn_login->setFont(font2);
        btn_login->setStyleSheet(QString::fromUtf8("color: rgb(255,167,129);\n"
"background-color: rgb(91,14,45);\n"
""));
        btn_help = new QPushButton(Widget);
        btn_help->setObjectName(QString::fromUtf8("btn_help"));
        btn_help->setGeometry(QRect(815, 60, 100, 30));
        btn_help->setFont(font2);
        btn_help->setStyleSheet(QString::fromUtf8("color: rgb(255,167,129);\n"
"background-color: rgb(91,14,45);\n"
""));
        txt_description = new QTextEdit(Widget);
        txt_description->setObjectName(QString::fromUtf8("txt_description"));
        txt_description->setGeometry(QRect(310, 510, 661, 191));
        txt_description->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
""));
        lbl_BG = new QLabel(Widget);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 1000, 720));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(255,167,129);"));
        lbl_warning = new QLabel(Widget);
        lbl_warning->setObjectName(QString::fromUtf8("lbl_warning"));
        lbl_warning->setGeometry(QRect(390, 20, 211, 71));
        lbl_warning->setFont(font);
        lbl_warning->setStyleSheet(QString::fromUtf8("color: rrgb(91,14,45);"));
        lbl_warning->setAlignment(Qt::AlignCenter);
        pic_1 = new QPushButton(Widget);
        pic_1->setObjectName(QString::fromUtf8("pic_1"));
        pic_1->setGeometry(QRect(850, 100, 120, 120));
        pic_1->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(91,14,45);\n"
""));
        pic_2 = new QPushButton(Widget);
        pic_2->setObjectName(QString::fromUtf8("pic_2"));
        pic_2->setGeometry(QRect(720, 100, 120, 120));
        pic_2->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(91,14,45);"));
        pic_3 = new QPushButton(Widget);
        pic_3->setObjectName(QString::fromUtf8("pic_3"));
        pic_3->setGeometry(QRect(850, 230, 120, 120));
        pic_3->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(91,14,45);"));
        pic_4 = new QPushButton(Widget);
        pic_4->setObjectName(QString::fromUtf8("pic_4"));
        pic_4->setGeometry(QRect(720, 230, 120, 120));
        pic_4->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(91,14,45);"));
        pic_5 = new QPushButton(Widget);
        pic_5->setObjectName(QString::fromUtf8("pic_5"));
        pic_5->setGeometry(QRect(850, 360, 120, 120));
        pic_5->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(91,14,45);"));
        pic_6 = new QPushButton(Widget);
        pic_6->setObjectName(QString::fromUtf8("pic_6"));
        pic_6->setGeometry(QRect(720, 360, 120, 120));
        pic_6->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(91,14,45);"));
        lbl_BG->raise();
        lbl_border->raise();
        lbl_search->raise();
        txt_search->raise();
        GP_SearchMethod->raise();
        tbl_search->raise();
        pic_0->raise();
        btn_register->raise();
        btn_login->raise();
        btn_help->raise();
        txt_description->raise();
        lbl_warning->raise();
        pic_1->raise();
        pic_2->raise();
        pic_3->raise();
        pic_4->raise();
        pic_5->raise();
        pic_6->raise();

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "P_Shop", nullptr));
        lbl_border->setText(QString());
        lbl_search->setText(QCoreApplication::translate("Widget", "Search :", nullptr));
        GP_SearchMethod->setTitle(QCoreApplication::translate("Widget", "Search by :", nullptr));
        radio_Name->setText(QCoreApplication::translate("Widget", "Name", nullptr));
        redio_Category->setText(QCoreApplication::translate("Widget", "Category", nullptr));
        pic_0->setText(QString());
        btn_register->setText(QCoreApplication::translate("Widget", "&Register", nullptr));
        btn_login->setText(QCoreApplication::translate("Widget", "&Login", nullptr));
        btn_help->setText(QCoreApplication::translate("Widget", "&Help", nullptr));
        lbl_BG->setText(QString());
        lbl_warning->setText(QCoreApplication::translate("Widget", "You are guest user\n"
"\n"
"Login or Register", nullptr));
        pic_1->setText(QString());
        pic_2->setText(QString());
        pic_3->setText(QString());
        pic_4->setText(QString());
        pic_5->setText(QString());
        pic_6->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
