/********************************************************************************
** Form generated from reading UI file 'verify_user.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VERIFY_USER_H
#define UI_VERIFY_USER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Verify_User
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QLabel *lbl_desc;
    QLabel *lbl_verify;
    QLineEdit *txt_verifyCode;
    QPushButton *btn_verify;
    QPushButton *btn_edit;

    void setupUi(QDialog *Verify_User)
    {
        if (Verify_User->objectName().isEmpty())
            Verify_User->setObjectName(QString::fromUtf8("Verify_User"));
        Verify_User->resize(530, 360);
        lbl_BG = new QLabel(Verify_User);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 530, 360));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(255,133,41);"));
        lbl_border = new QLabel(Verify_User);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(15, 15, 500, 330));
        lbl_border->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(47,48,43);"));
        lbl_desc = new QLabel(Verify_User);
        lbl_desc->setObjectName(QString::fromUtf8("lbl_desc"));
        lbl_desc->setGeometry(QRect(64, 40, 402, 31));
        QFont font;
        font.setPointSize(13);
        font.setBold(true);
        font.setWeight(75);
        lbl_desc->setFont(font);
        lbl_desc->setStyleSheet(QString::fromUtf8("color: rgbrgb(47,48,43);"));
        lbl_verify = new QLabel(Verify_User);
        lbl_verify->setObjectName(QString::fromUtf8("lbl_verify"));
        lbl_verify->setGeometry(QRect(175, 110, 180, 31));
        QFont font1;
        font1.setPointSize(15);
        font1.setBold(true);
        font1.setWeight(75);
        lbl_verify->setFont(font1);
        lbl_verify->setStyleSheet(QString::fromUtf8("color: rgbrgb(47,48,43);"));
        txt_verifyCode = new QLineEdit(Verify_User);
        txt_verifyCode->setObjectName(QString::fromUtf8("txt_verifyCode"));
        txt_verifyCode->setGeometry(QRect(175, 150, 180, 50));
        QFont font2;
        font2.setPointSize(25);
        font2.setBold(true);
        font2.setWeight(75);
        txt_verifyCode->setFont(font2);
        txt_verifyCode->setStyleSheet(QString::fromUtf8("border: 5px solid rgb(47,48,43);"));
        txt_verifyCode->setAlignment(Qt::AlignCenter);
        btn_verify = new QPushButton(Verify_User);
        btn_verify->setObjectName(QString::fromUtf8("btn_verify"));
        btn_verify->setGeometry(QRect(270, 300, 100, 30));
        QFont font3;
        font3.setPointSize(12);
        font3.setBold(true);
        font3.setWeight(75);
        btn_verify->setFont(font3);
        btn_edit = new QPushButton(Verify_User);
        btn_edit->setObjectName(QString::fromUtf8("btn_edit"));
        btn_edit->setGeometry(QRect(160, 300, 100, 30));
        btn_edit->setFont(font3);
        QWidget::setTabOrder(txt_verifyCode, btn_verify);
        QWidget::setTabOrder(btn_verify, btn_edit);

        retranslateUi(Verify_User);

        QMetaObject::connectSlotsByName(Verify_User);
    } // setupUi

    void retranslateUi(QDialog *Verify_User)
    {
        Verify_User->setWindowTitle(QCoreApplication::translate("Verify_User", "Verification", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        lbl_desc->setText(QCoreApplication::translate("Verify_User", "Check your email and enter verification code here", nullptr));
        lbl_verify->setText(QCoreApplication::translate("Verify_User", "Verification Code :", nullptr));
        txt_verifyCode->setText(QString());
        btn_verify->setText(QCoreApplication::translate("Verify_User", "&Verify", nullptr));
        btn_edit->setText(QCoreApplication::translate("Verify_User", "&Edit info", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Verify_User: public Ui_Verify_User {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VERIFY_USER_H
