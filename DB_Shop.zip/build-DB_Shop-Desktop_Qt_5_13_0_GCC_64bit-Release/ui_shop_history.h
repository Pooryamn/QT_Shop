/********************************************************************************
** Form generated from reading UI file 'shop_history.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOP_HISTORY_H
#define UI_SHOP_HISTORY_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_Shop_history
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QTableView *tbl_history;
    QPushButton *btn_viewditail;

    void setupUi(QDialog *Shop_history)
    {
        if (Shop_history->objectName().isEmpty())
            Shop_history->setObjectName(QString::fromUtf8("Shop_history"));
        Shop_history->resize(1000, 600);
        lbl_BG = new QLabel(Shop_history);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 1000, 600));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(53, 133, 151);"));
        lbl_border = new QLabel(Shop_history);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(15, 15, 970, 570));
        lbl_border->setStyleSheet(QString::fromUtf8("border:5px solid rgb(244, 168, 150)"));
        tbl_history = new QTableView(Shop_history);
        tbl_history->setObjectName(QString::fromUtf8("tbl_history"));
        tbl_history->setGeometry(QRect(40, 85, 920, 480));
        tbl_history->setStyleSheet(QString::fromUtf8(""));
        btn_viewditail = new QPushButton(Shop_history);
        btn_viewditail->setObjectName(QString::fromUtf8("btn_viewditail"));
        btn_viewditail->setGeometry(QRect(40, 40, 150, 35));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        btn_viewditail->setFont(font);
        btn_viewditail->setStyleSheet(QString::fromUtf8("background-color: rgb(244, 168, 150);\n"
"color: rgb(53, 133, 151);"));

        retranslateUi(Shop_history);

        QMetaObject::connectSlotsByName(Shop_history);
    } // setupUi

    void retranslateUi(QDialog *Shop_history)
    {
        Shop_history->setWindowTitle(QCoreApplication::translate("Shop_history", "Shop History", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        btn_viewditail->setText(QCoreApplication::translate("Shop_history", "&View Ditails", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Shop_history: public Ui_Shop_history {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOP_HISTORY_H
