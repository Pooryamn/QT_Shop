/********************************************************************************
** Form generated from reading UI file 'user_edit.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USER_EDIT_H
#define UI_USER_EDIT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_user_edit
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QLabel *lbl_firstname;
    QLineEdit *txt_name;
    QLabel *lbl_family;
    QLineEdit *txt_lastname;
    QLineEdit *txt_email;
    QLabel *lbl_email;
    QLabel *lbl_mobile;
    QLineEdit *txt_mobile;
    QLineEdit *txt_home;
    QLabel *lbl_home;
    QLabel *lbl_birth;
    QLabel *pic_profile;
    QPushButton *btn_load;
    QPushButton *btn_clear;
    QPushButton *btn_close;
    QPushButton *btn_cansel;
    QLabel *lbl_city;
    QLineEdit *txt_city;
    QLineEdit *txt_post;
    QLabel *lbl_post;
    QLineEdit *txt_user;
    QLabel *lbl_user;
    QLineEdit *txt_pass;
    QLabel *lbl_pass1;
    QLineEdit *txt_comfrim;
    QLabel *lbl_pass2;
    QLabel *lbl_pass2_2;
    QTextEdit *textEdit;
    QPushButton *btn_save;
    QLineEdit *txt_month;
    QLabel *lbl_slah;
    QLineEdit *txt_day;
    QLabel *lbl_slah_2;
    QLineEdit *txt_year;

    void setupUi(QDialog *user_edit)
    {
        if (user_edit->objectName().isEmpty())
            user_edit->setObjectName(QString::fromUtf8("user_edit"));
        user_edit->resize(1000, 620);
        lbl_BG = new QLabel(user_edit);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 1000, 620));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(53, 133, 151)"));
        lbl_border = new QLabel(user_edit);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(10, 10, 970, 600));
        lbl_border->setStyleSheet(QString::fromUtf8("border:5px solid rgb(244, 168, 150)"));
        lbl_firstname = new QLabel(user_edit);
        lbl_firstname->setObjectName(QString::fromUtf8("lbl_firstname"));
        lbl_firstname->setGeometry(QRect(40, 30, 100, 20));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        lbl_firstname->setFont(font);
        lbl_firstname->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150)"));
        txt_name = new QLineEdit(user_edit);
        txt_name->setObjectName(QString::fromUtf8("txt_name"));
        txt_name->setGeometry(QRect(40, 60, 250, 30));
        txt_name->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(244, 168, 150)"));
        lbl_family = new QLabel(user_edit);
        lbl_family->setObjectName(QString::fromUtf8("lbl_family"));
        lbl_family->setGeometry(QRect(40, 110, 100, 20));
        lbl_family->setFont(font);
        lbl_family->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150)"));
        txt_lastname = new QLineEdit(user_edit);
        txt_lastname->setObjectName(QString::fromUtf8("txt_lastname"));
        txt_lastname->setGeometry(QRect(40, 140, 250, 30));
        txt_lastname->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(244, 168, 150)"));
        txt_email = new QLineEdit(user_edit);
        txt_email->setObjectName(QString::fromUtf8("txt_email"));
        txt_email->setGeometry(QRect(40, 220, 250, 30));
        txt_email->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(244, 168, 150)"));
        lbl_email = new QLabel(user_edit);
        lbl_email->setObjectName(QString::fromUtf8("lbl_email"));
        lbl_email->setGeometry(QRect(40, 190, 100, 20));
        lbl_email->setFont(font);
        lbl_email->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150)"));
        lbl_mobile = new QLabel(user_edit);
        lbl_mobile->setObjectName(QString::fromUtf8("lbl_mobile"));
        lbl_mobile->setGeometry(QRect(40, 270, 141, 20));
        lbl_mobile->setFont(font);
        lbl_mobile->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150)"));
        txt_mobile = new QLineEdit(user_edit);
        txt_mobile->setObjectName(QString::fromUtf8("txt_mobile"));
        txt_mobile->setGeometry(QRect(40, 300, 250, 30));
        txt_mobile->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(244, 168, 150)"));
        txt_home = new QLineEdit(user_edit);
        txt_home->setObjectName(QString::fromUtf8("txt_home"));
        txt_home->setGeometry(QRect(40, 380, 250, 30));
        txt_home->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(244, 168, 150)"));
        lbl_home = new QLabel(user_edit);
        lbl_home->setObjectName(QString::fromUtf8("lbl_home"));
        lbl_home->setGeometry(QRect(40, 350, 141, 16));
        lbl_home->setFont(font);
        lbl_home->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150)"));
        lbl_birth = new QLabel(user_edit);
        lbl_birth->setObjectName(QString::fromUtf8("lbl_birth"));
        lbl_birth->setGeometry(QRect(40, 430, 141, 16));
        lbl_birth->setFont(font);
        lbl_birth->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150)"));
        pic_profile = new QLabel(user_edit);
        pic_profile->setObjectName(QString::fromUtf8("pic_profile"));
        pic_profile->setGeometry(QRect(720, 50, 240, 320));
        pic_profile->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 4px solid rgb(244, 168, 150);"));
        btn_load = new QPushButton(user_edit);
        btn_load->setObjectName(QString::fromUtf8("btn_load"));
        btn_load->setGeometry(QRect(780, 390, 120, 30));
        btn_load->setStyleSheet(QString::fromUtf8("background-color: rgb(244, 168, 150);\n"
"color: rgb(53, 133, 151);"));
        btn_clear = new QPushButton(user_edit);
        btn_clear->setObjectName(QString::fromUtf8("btn_clear"));
        btn_clear->setGeometry(QRect(780, 430, 120, 30));
        btn_clear->setStyleSheet(QString::fromUtf8("background-color: rgb(244, 168, 150);\n"
"color: rgb(53, 133, 151);"));
        btn_close = new QPushButton(user_edit);
        btn_close->setObjectName(QString::fromUtf8("btn_close"));
        btn_close->setGeometry(QRect(840, 560, 120, 30));
        btn_close->setStyleSheet(QString::fromUtf8("background-color: rgb(244, 168, 150);\n"
"color: rgb(53, 133, 151);"));
        btn_cansel = new QPushButton(user_edit);
        btn_cansel->setObjectName(QString::fromUtf8("btn_cansel"));
        btn_cansel->setGeometry(QRect(710, 560, 120, 30));
        btn_cansel->setStyleSheet(QString::fromUtf8("background-color: rgb(244, 168, 150);\n"
"color: rgb(53, 133, 151);"));
        lbl_city = new QLabel(user_edit);
        lbl_city->setObjectName(QString::fromUtf8("lbl_city"));
        lbl_city->setGeometry(QRect(370, 30, 100, 20));
        lbl_city->setFont(font);
        lbl_city->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150)\n"
""));
        txt_city = new QLineEdit(user_edit);
        txt_city->setObjectName(QString::fromUtf8("txt_city"));
        txt_city->setGeometry(QRect(370, 60, 250, 30));
        txt_city->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(244, 168, 150)"));
        txt_post = new QLineEdit(user_edit);
        txt_post->setObjectName(QString::fromUtf8("txt_post"));
        txt_post->setGeometry(QRect(370, 140, 250, 30));
        txt_post->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(244, 168, 150)"));
        lbl_post = new QLabel(user_edit);
        lbl_post->setObjectName(QString::fromUtf8("lbl_post"));
        lbl_post->setGeometry(QRect(370, 110, 100, 20));
        lbl_post->setFont(font);
        lbl_post->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150);"));
        txt_user = new QLineEdit(user_edit);
        txt_user->setObjectName(QString::fromUtf8("txt_user"));
        txt_user->setGeometry(QRect(370, 220, 250, 30));
        txt_user->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(244, 168, 150)"));
        lbl_user = new QLabel(user_edit);
        lbl_user->setObjectName(QString::fromUtf8("lbl_user"));
        lbl_user->setGeometry(QRect(370, 190, 100, 20));
        lbl_user->setFont(font);
        lbl_user->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150);"));
        txt_pass = new QLineEdit(user_edit);
        txt_pass->setObjectName(QString::fromUtf8("txt_pass"));
        txt_pass->setGeometry(QRect(370, 300, 250, 30));
        txt_pass->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(244, 168, 150)"));
        lbl_pass1 = new QLabel(user_edit);
        lbl_pass1->setObjectName(QString::fromUtf8("lbl_pass1"));
        lbl_pass1->setGeometry(QRect(370, 270, 131, 20));
        lbl_pass1->setFont(font);
        lbl_pass1->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150);"));
        txt_comfrim = new QLineEdit(user_edit);
        txt_comfrim->setObjectName(QString::fromUtf8("txt_comfrim"));
        txt_comfrim->setGeometry(QRect(370, 380, 250, 30));
        txt_comfrim->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(244, 168, 150)"));
        lbl_pass2 = new QLabel(user_edit);
        lbl_pass2->setObjectName(QString::fromUtf8("lbl_pass2"));
        lbl_pass2->setGeometry(QRect(370, 350, 191, 20));
        lbl_pass2->setFont(font);
        lbl_pass2->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150);"));
        lbl_pass2_2 = new QLabel(user_edit);
        lbl_pass2_2->setObjectName(QString::fromUtf8("lbl_pass2_2"));
        lbl_pass2_2->setGeometry(QRect(370, 430, 151, 20));
        lbl_pass2_2->setFont(font);
        lbl_pass2_2->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150);"));
        textEdit = new QTextEdit(user_edit);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(370, 460, 251, 131));
        textEdit->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(244, 168, 150)"));
        btn_save = new QPushButton(user_edit);
        btn_save->setObjectName(QString::fromUtf8("btn_save"));
        btn_save->setGeometry(QRect(780, 500, 120, 30));
        btn_save->setStyleSheet(QString::fromUtf8("background-color: rgb(244, 168, 150);\n"
"color: rgb(53, 133, 151);"));
        txt_month = new QLineEdit(user_edit);
        txt_month->setObjectName(QString::fromUtf8("txt_month"));
        txt_month->setGeometry(QRect(120, 460, 51, 30));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setWeight(75);
        txt_month->setFont(font1);
        txt_month->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(244, 168, 150);"));
        txt_month->setAlignment(Qt::AlignCenter);
        lbl_slah = new QLabel(user_edit);
        lbl_slah->setObjectName(QString::fromUtf8("lbl_slah"));
        lbl_slah->setGeometry(QRect(105, 465, 16, 20));
        lbl_slah->setFont(font);
        lbl_slah->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150)"));
        txt_day = new QLineEdit(user_edit);
        txt_day->setObjectName(QString::fromUtf8("txt_day"));
        txt_day->setGeometry(QRect(190, 460, 51, 30));
        txt_day->setFont(font1);
        txt_day->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(244, 168, 150);"));
        txt_day->setAlignment(Qt::AlignCenter);
        lbl_slah_2 = new QLabel(user_edit);
        lbl_slah_2->setObjectName(QString::fromUtf8("lbl_slah_2"));
        lbl_slah_2->setGeometry(QRect(175, 465, 16, 20));
        lbl_slah_2->setFont(font);
        lbl_slah_2->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150)"));
        txt_year = new QLineEdit(user_edit);
        txt_year->setObjectName(QString::fromUtf8("txt_year"));
        txt_year->setGeometry(QRect(50, 460, 51, 30));
        txt_year->setFont(font1);
        txt_year->setStyleSheet(QString::fromUtf8("border: 3px solid rgb(244, 168, 150);"));
        txt_year->setAlignment(Qt::AlignCenter);
        QWidget::setTabOrder(txt_name, txt_lastname);
        QWidget::setTabOrder(txt_lastname, txt_email);
        QWidget::setTabOrder(txt_email, txt_mobile);
        QWidget::setTabOrder(txt_mobile, txt_home);

        retranslateUi(user_edit);

        QMetaObject::connectSlotsByName(user_edit);
    } // setupUi

    void retranslateUi(QDialog *user_edit)
    {
        user_edit->setWindowTitle(QCoreApplication::translate("user_edit", "Edit profile ...", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        lbl_firstname->setText(QCoreApplication::translate("user_edit", "Firstname* : ", nullptr));
        lbl_family->setText(QCoreApplication::translate("user_edit", "Lastname* :", nullptr));
        lbl_email->setText(QCoreApplication::translate("user_edit", "Email* :", nullptr));
        lbl_mobile->setText(QCoreApplication::translate("user_edit", "Mobile number* :", nullptr));
        lbl_home->setText(QCoreApplication::translate("user_edit", "Phone number :", nullptr));
        lbl_birth->setText(QCoreApplication::translate("user_edit", "Birthdate :", nullptr));
        pic_profile->setText(QString());
        btn_load->setText(QCoreApplication::translate("user_edit", "&Load", nullptr));
        btn_clear->setText(QCoreApplication::translate("user_edit", "&Clear", nullptr));
        btn_close->setText(QCoreApplication::translate("user_edit", "Cl&ose", nullptr));
        btn_cansel->setText(QCoreApplication::translate("user_edit", "C&ancel", nullptr));
        lbl_city->setText(QCoreApplication::translate("user_edit", "City :", nullptr));
        lbl_post->setText(QCoreApplication::translate("user_edit", "Postal Code :", nullptr));
        txt_user->setText(QString());
        lbl_user->setText(QCoreApplication::translate("user_edit", "Username* :", nullptr));
        lbl_pass1->setText(QCoreApplication::translate("user_edit", "New Password :", nullptr));
        lbl_pass2->setText(QCoreApplication::translate("user_edit", "Comfrim New Password :", nullptr));
        lbl_pass2_2->setText(QCoreApplication::translate("user_edit", "Address :", nullptr));
        btn_save->setText(QCoreApplication::translate("user_edit", "&Save", nullptr));
        txt_month->setText(QString());
        lbl_slah->setText(QCoreApplication::translate("user_edit", "/", nullptr));
        txt_day->setText(QString());
        lbl_slah_2->setText(QCoreApplication::translate("user_edit", "/", nullptr));
        txt_year->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class user_edit: public Ui_user_edit {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USER_EDIT_H
