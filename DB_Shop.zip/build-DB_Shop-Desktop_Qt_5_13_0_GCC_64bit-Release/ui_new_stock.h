/********************************************************************************
** Form generated from reading UI file 'new_stock.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEW_STOCK_H
#define UI_NEW_STOCK_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_new_stock
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QLabel *lbl_supplier;
    QTableView *tbl_supplier;
    QPushButton *btn_addsupplier;
    QLabel *lbl_category;
    QLineEdit *txt_category;
    QLineEdit *txt_cost;
    QLabel *lbl_cost;
    QLabel *lbl_name;
    QLineEdit *txt_name;
    QLabel *lbl_stock;
    QLineEdit *txt_stock;
    QLabel *pic_1;
    QLabel *lbl_desc;
    QLabel *pic_2;
    QLabel *pic_3;
    QLabel *pic_4;
    QLabel *pic_5;
    QLabel *pic_6;
    QPushButton *btn_choose1;
    QPushButton *btn_choose2;
    QPushButton *btn_choose3;
    QPushButton *btn_choose4;
    QPushButton *btn_choose5;
    QPushButton *btn_choose6;
    QTextEdit *textEdit;
    QPushButton *btn_addstock;

    void setupUi(QDialog *new_stock)
    {
        if (new_stock->objectName().isEmpty())
            new_stock->setObjectName(QString::fromUtf8("new_stock"));
        new_stock->resize(1000, 600);
        lbl_BG = new QLabel(new_stock);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 1000, 600));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(53, 133, 151);"));
        lbl_border = new QLabel(new_stock);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(15, 15, 970, 570));
        lbl_border->setStyleSheet(QString::fromUtf8("border:5px solid rgb(244, 168, 150)"));
        lbl_supplier = new QLabel(new_stock);
        lbl_supplier->setObjectName(QString::fromUtf8("lbl_supplier"));
        lbl_supplier->setGeometry(QRect(30, 30, 81, 30));
        QFont font;
        font.setPointSize(13);
        font.setBold(true);
        font.setWeight(75);
        lbl_supplier->setFont(font);
        lbl_supplier->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150);"));
        tbl_supplier = new QTableView(new_stock);
        tbl_supplier->setObjectName(QString::fromUtf8("tbl_supplier"));
        tbl_supplier->setGeometry(QRect(30, 60, 180, 461));
        tbl_supplier->setStyleSheet(QString::fromUtf8(""));
        btn_addsupplier = new QPushButton(new_stock);
        btn_addsupplier->setObjectName(QString::fromUtf8("btn_addsupplier"));
        btn_addsupplier->setGeometry(QRect(30, 530, 180, 30));
        btn_addsupplier->setFont(font);
        btn_addsupplier->setStyleSheet(QString::fromUtf8("background-color: rgb(244, 168, 150);\n"
"color: rgb(53, 133, 151);"));
        lbl_category = new QLabel(new_stock);
        lbl_category->setObjectName(QString::fromUtf8("lbl_category"));
        lbl_category->setGeometry(QRect(280, 120, 91, 30));
        lbl_category->setFont(font);
        lbl_category->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150);"));
        txt_category = new QLineEdit(new_stock);
        txt_category->setObjectName(QString::fromUtf8("txt_category"));
        txt_category->setGeometry(QRect(280, 150, 180, 30));
        txt_category->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(244, 168, 150)"));
        txt_cost = new QLineEdit(new_stock);
        txt_cost->setObjectName(QString::fromUtf8("txt_cost"));
        txt_cost->setGeometry(QRect(280, 220, 180, 30));
        txt_cost->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(244, 168, 150)"));
        lbl_cost = new QLabel(new_stock);
        lbl_cost->setObjectName(QString::fromUtf8("lbl_cost"));
        lbl_cost->setGeometry(QRect(280, 190, 141, 30));
        lbl_cost->setFont(font);
        lbl_cost->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150);"));
        lbl_name = new QLabel(new_stock);
        lbl_name->setObjectName(QString::fromUtf8("lbl_name"));
        lbl_name->setGeometry(QRect(280, 50, 141, 30));
        lbl_name->setFont(font);
        lbl_name->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150);"));
        txt_name = new QLineEdit(new_stock);
        txt_name->setObjectName(QString::fromUtf8("txt_name"));
        txt_name->setGeometry(QRect(280, 80, 180, 30));
        txt_name->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(244, 168, 150)"));
        lbl_stock = new QLabel(new_stock);
        lbl_stock->setObjectName(QString::fromUtf8("lbl_stock"));
        lbl_stock->setGeometry(QRect(280, 260, 141, 30));
        lbl_stock->setFont(font);
        lbl_stock->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150);"));
        txt_stock = new QLineEdit(new_stock);
        txt_stock->setObjectName(QString::fromUtf8("txt_stock"));
        txt_stock->setGeometry(QRect(280, 290, 180, 30));
        txt_stock->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(244, 168, 150)"));
        pic_1 = new QLabel(new_stock);
        pic_1->setObjectName(QString::fromUtf8("pic_1"));
        pic_1->setGeometry(QRect(540, 60, 120, 120));
        pic_1->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(244, 168, 150);\n"
"background-color: rgb(255, 255, 255);"));
        lbl_desc = new QLabel(new_stock);
        lbl_desc->setObjectName(QString::fromUtf8("lbl_desc"));
        lbl_desc->setGeometry(QRect(230, 420, 141, 30));
        lbl_desc->setFont(font);
        lbl_desc->setStyleSheet(QString::fromUtf8("color: rgb(244, 168, 150);"));
        pic_2 = new QLabel(new_stock);
        pic_2->setObjectName(QString::fromUtf8("pic_2"));
        pic_2->setGeometry(QRect(670, 60, 120, 120));
        pic_2->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(244, 168, 150);\n"
"background-color: rgb(255, 255, 255);"));
        pic_3 = new QLabel(new_stock);
        pic_3->setObjectName(QString::fromUtf8("pic_3"));
        pic_3->setGeometry(QRect(800, 60, 120, 120));
        pic_3->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(244, 168, 150);\n"
"background-color: rgb(255, 255, 255);"));
        pic_4 = new QLabel(new_stock);
        pic_4->setObjectName(QString::fromUtf8("pic_4"));
        pic_4->setGeometry(QRect(540, 250, 120, 120));
        pic_4->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(244, 168, 150);\n"
"background-color: rgb(255, 255, 255);"));
        pic_5 = new QLabel(new_stock);
        pic_5->setObjectName(QString::fromUtf8("pic_5"));
        pic_5->setGeometry(QRect(670, 250, 120, 120));
        pic_5->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(244, 168, 150);\n"
"background-color: rgb(255, 255, 255);"));
        pic_6 = new QLabel(new_stock);
        pic_6->setObjectName(QString::fromUtf8("pic_6"));
        pic_6->setGeometry(QRect(800, 250, 120, 120));
        pic_6->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(244, 168, 150);\n"
"background-color: rgb(255, 255, 255);"));
        btn_choose1 = new QPushButton(new_stock);
        btn_choose1->setObjectName(QString::fromUtf8("btn_choose1"));
        btn_choose1->setGeometry(QRect(540, 190, 120, 30));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setWeight(75);
        btn_choose1->setFont(font1);
        btn_choose1->setStyleSheet(QString::fromUtf8("color: rgb(53, 133, 151);\n"
"background-color: rgb(244, 168, 150);"));
        btn_choose2 = new QPushButton(new_stock);
        btn_choose2->setObjectName(QString::fromUtf8("btn_choose2"));
        btn_choose2->setGeometry(QRect(670, 190, 120, 30));
        btn_choose2->setFont(font1);
        btn_choose2->setStyleSheet(QString::fromUtf8("color: rgb(53, 133, 151);\n"
"background-color: rgb(244, 168, 150);"));
        btn_choose3 = new QPushButton(new_stock);
        btn_choose3->setObjectName(QString::fromUtf8("btn_choose3"));
        btn_choose3->setGeometry(QRect(800, 190, 120, 30));
        btn_choose3->setFont(font1);
        btn_choose3->setStyleSheet(QString::fromUtf8("color: rgb(53, 133, 151);\n"
"background-color: rgb(244, 168, 150);"));
        btn_choose4 = new QPushButton(new_stock);
        btn_choose4->setObjectName(QString::fromUtf8("btn_choose4"));
        btn_choose4->setGeometry(QRect(540, 380, 120, 30));
        btn_choose4->setFont(font1);
        btn_choose4->setStyleSheet(QString::fromUtf8("color: rgb(53, 133, 151);\n"
"background-color: rgb(244, 168, 150);"));
        btn_choose5 = new QPushButton(new_stock);
        btn_choose5->setObjectName(QString::fromUtf8("btn_choose5"));
        btn_choose5->setGeometry(QRect(670, 380, 120, 30));
        btn_choose5->setFont(font1);
        btn_choose5->setStyleSheet(QString::fromUtf8("color: rgb(53, 133, 151);\n"
"background-color: rgb(244, 168, 150);"));
        btn_choose6 = new QPushButton(new_stock);
        btn_choose6->setObjectName(QString::fromUtf8("btn_choose6"));
        btn_choose6->setGeometry(QRect(800, 380, 120, 30));
        btn_choose6->setFont(font1);
        btn_choose6->setStyleSheet(QString::fromUtf8("color: rgb(53, 133, 151);\n"
"background-color: rgb(244, 168, 150);"));
        textEdit = new QTextEdit(new_stock);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(230, 460, 731, 101));
        btn_addstock = new QPushButton(new_stock);
        btn_addstock->setObjectName(QString::fromUtf8("btn_addstock"));
        btn_addstock->setGeometry(QRect(280, 370, 180, 30));
        btn_addstock->setFont(font);
        btn_addstock->setStyleSheet(QString::fromUtf8("background-color: rgb(244, 168, 150);\n"
"color: rgb(53, 133, 151);"));
        QWidget::setTabOrder(tbl_supplier, btn_addsupplier);
        QWidget::setTabOrder(btn_addsupplier, txt_name);
        QWidget::setTabOrder(txt_name, txt_category);
        QWidget::setTabOrder(txt_category, txt_cost);
        QWidget::setTabOrder(txt_cost, txt_stock);
        QWidget::setTabOrder(txt_stock, btn_choose1);
        QWidget::setTabOrder(btn_choose1, btn_choose2);
        QWidget::setTabOrder(btn_choose2, btn_choose3);
        QWidget::setTabOrder(btn_choose3, btn_choose4);
        QWidget::setTabOrder(btn_choose4, btn_choose5);
        QWidget::setTabOrder(btn_choose5, btn_choose6);
        QWidget::setTabOrder(btn_choose6, textEdit);
        QWidget::setTabOrder(textEdit, btn_addstock);

        retranslateUi(new_stock);

        QMetaObject::connectSlotsByName(new_stock);
    } // setupUi

    void retranslateUi(QDialog *new_stock)
    {
        new_stock->setWindowTitle(QCoreApplication::translate("new_stock", "Add new stock", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        lbl_supplier->setText(QCoreApplication::translate("new_stock", "Supplier* :", nullptr));
        btn_addsupplier->setText(QCoreApplication::translate("new_stock", "+ Add Supplier", nullptr));
        lbl_category->setText(QCoreApplication::translate("new_stock", "Category* :", nullptr));
        lbl_cost->setText(QCoreApplication::translate("new_stock", "Cost (Rials)* :", nullptr));
        lbl_name->setText(QCoreApplication::translate("new_stock", "Product Name* :", nullptr));
        lbl_stock->setText(QCoreApplication::translate("new_stock", "Stock* :", nullptr));
        pic_1->setText(QString());
        lbl_desc->setText(QCoreApplication::translate("new_stock", "Description* :", nullptr));
        pic_2->setText(QString());
        pic_3->setText(QString());
        pic_4->setText(QString());
        pic_5->setText(QString());
        pic_6->setText(QString());
        btn_choose1->setText(QCoreApplication::translate("new_stock", "Choose ...", nullptr));
        btn_choose2->setText(QCoreApplication::translate("new_stock", "Choose ...", nullptr));
        btn_choose3->setText(QCoreApplication::translate("new_stock", "Choose ...", nullptr));
        btn_choose4->setText(QCoreApplication::translate("new_stock", "Choose ...", nullptr));
        btn_choose5->setText(QCoreApplication::translate("new_stock", "Choose ...", nullptr));
        btn_choose6->setText(QCoreApplication::translate("new_stock", "Choose ...", nullptr));
        btn_addstock->setText(QCoreApplication::translate("new_stock", "ADD", nullptr));
    } // retranslateUi

};

namespace Ui {
    class new_stock: public Ui_new_stock {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEW_STOCK_H
