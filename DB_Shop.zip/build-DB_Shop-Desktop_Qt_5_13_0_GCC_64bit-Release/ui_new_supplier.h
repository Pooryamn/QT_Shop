/********************************************************************************
** Form generated from reading UI file 'new_supplier.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEW_SUPPLIER_H
#define UI_NEW_SUPPLIER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_New_supplier
{
public:
    QLabel *lbl_BG;
    QLabel *lbl_border;
    QLabel *lbl_company;
    QLineEdit *txt_company;
    QLabel *lbl_email;
    QLineEdit *txt_email;
    QLabel *lbl_phone;
    QLineEdit *txt_phone;
    QLineEdit *txt_type;
    QLabel *lbl_type;
    QLabel *pic;
    QPushButton *btn_choose;
    QPushButton *btn_clear;
    QPushButton *btn_save;

    void setupUi(QDialog *New_supplier)
    {
        if (New_supplier->objectName().isEmpty())
            New_supplier->setObjectName(QString::fromUtf8("New_supplier"));
        New_supplier->resize(800, 600);
        lbl_BG = new QLabel(New_supplier);
        lbl_BG->setObjectName(QString::fromUtf8("lbl_BG"));
        lbl_BG->setGeometry(QRect(0, 0, 800, 600));
        lbl_BG->setStyleSheet(QString::fromUtf8("background-color: rgb(91, 14, 45);"));
        lbl_border = new QLabel(New_supplier);
        lbl_border->setObjectName(QString::fromUtf8("lbl_border"));
        lbl_border->setGeometry(QRect(15, 15, 770, 570));
        QFont font;
        font.setPointSize(24);
        font.setBold(true);
        font.setUnderline(false);
        font.setWeight(75);
        lbl_border->setFont(font);
        lbl_border->setStyleSheet(QString::fromUtf8("border: 4px solid rgb(255, 167, 129);"));
        lbl_company = new QLabel(New_supplier);
        lbl_company->setObjectName(QString::fromUtf8("lbl_company"));
        lbl_company->setGeometry(QRect(40, 40, 161, 51));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Ubuntu Condensed"));
        font1.setPointSize(18);
        font1.setBold(false);
        font1.setItalic(true);
        font1.setWeight(9);
        lbl_company->setFont(font1);
        lbl_company->setStyleSheet(QString::fromUtf8("font: 75 italic 18pt \"Ubuntu Condensed\";\n"
"color: rgb(255, 167, 129);"));
        txt_company = new QLineEdit(New_supplier);
        txt_company->setObjectName(QString::fromUtf8("txt_company"));
        txt_company->setGeometry(QRect(40, 90, 250, 40));
        QFont font2;
        font2.setBold(true);
        font2.setWeight(75);
        txt_company->setFont(font2);
        txt_company->setStyleSheet(QString::fromUtf8("border:4px solid rgb(255, 167, 129);"));
        lbl_email = new QLabel(New_supplier);
        lbl_email->setObjectName(QString::fromUtf8("lbl_email"));
        lbl_email->setGeometry(QRect(40, 150, 161, 51));
        lbl_email->setFont(font1);
        lbl_email->setStyleSheet(QString::fromUtf8("font: 75 italic 18pt \"Ubuntu Condensed\";\n"
"color: rgb(255, 167, 129);"));
        txt_email = new QLineEdit(New_supplier);
        txt_email->setObjectName(QString::fromUtf8("txt_email"));
        txt_email->setGeometry(QRect(40, 200, 250, 40));
        txt_email->setFont(font2);
        txt_email->setStyleSheet(QString::fromUtf8("border:4px solid rgb(255, 167, 129);"));
        lbl_phone = new QLabel(New_supplier);
        lbl_phone->setObjectName(QString::fromUtf8("lbl_phone"));
        lbl_phone->setGeometry(QRect(40, 260, 161, 51));
        lbl_phone->setFont(font1);
        lbl_phone->setStyleSheet(QString::fromUtf8("font: 75 italic 18pt \"Ubuntu Condensed\";\n"
"color: rgb(255, 167, 129);"));
        txt_phone = new QLineEdit(New_supplier);
        txt_phone->setObjectName(QString::fromUtf8("txt_phone"));
        txt_phone->setGeometry(QRect(40, 310, 250, 40));
        txt_phone->setFont(font2);
        txt_phone->setStyleSheet(QString::fromUtf8("border:4px solid rgb(255, 167, 129);"));
        txt_type = new QLineEdit(New_supplier);
        txt_type->setObjectName(QString::fromUtf8("txt_type"));
        txt_type->setGeometry(QRect(40, 420, 250, 40));
        txt_type->setFont(font2);
        txt_type->setStyleSheet(QString::fromUtf8("border:4px solid rgb(255, 167, 129);"));
        lbl_type = new QLabel(New_supplier);
        lbl_type->setObjectName(QString::fromUtf8("lbl_type"));
        lbl_type->setGeometry(QRect(40, 370, 161, 51));
        lbl_type->setFont(font1);
        lbl_type->setStyleSheet(QString::fromUtf8("font: 75 italic 18pt \"Ubuntu Condensed\";\n"
"color: rgb(255, 167, 129);"));
        pic = new QLabel(New_supplier);
        pic->setObjectName(QString::fromUtf8("pic"));
        pic->setGeometry(QRect(430, 60, 240, 320));
        pic->setStyleSheet(QString::fromUtf8("border:5px solid rgb(255, 167, 129);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        btn_choose = new QPushButton(New_supplier);
        btn_choose->setObjectName(QString::fromUtf8("btn_choose"));
        btn_choose->setGeometry(QRect(450, 410, 200, 35));
        QFont font3;
        font3.setPointSize(13);
        font3.setBold(true);
        font3.setWeight(75);
        btn_choose->setFont(font3);
        btn_choose->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 167, 129);\n"
"color: rgb(91, 14, 45);"));
        btn_clear = new QPushButton(New_supplier);
        btn_clear->setObjectName(QString::fromUtf8("btn_clear"));
        btn_clear->setGeometry(QRect(470, 450, 160, 35));
        btn_clear->setFont(font3);
        btn_clear->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 167, 129);\n"
"color: rgb(91, 14, 45);"));
        btn_save = new QPushButton(New_supplier);
        btn_save->setObjectName(QString::fromUtf8("btn_save"));
        btn_save->setGeometry(QRect(470, 510, 160, 35));
        btn_save->setFont(font3);
        btn_save->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 167, 129);\n"
"color: rgb(91, 14, 45);"));

        retranslateUi(New_supplier);

        QMetaObject::connectSlotsByName(New_supplier);
    } // setupUi

    void retranslateUi(QDialog *New_supplier)
    {
        New_supplier->setWindowTitle(QCoreApplication::translate("New_supplier", "Supplier", nullptr));
        lbl_BG->setText(QString());
        lbl_border->setText(QString());
        lbl_company->setText(QCoreApplication::translate("New_supplier", "Company Name* :", nullptr));
        lbl_email->setText(QCoreApplication::translate("New_supplier", "Email Address* :", nullptr));
        lbl_phone->setText(QCoreApplication::translate("New_supplier", "Phone number :", nullptr));
        lbl_type->setText(QCoreApplication::translate("New_supplier", "Company Type* :", nullptr));
        pic->setText(QString());
        btn_choose->setText(QCoreApplication::translate("New_supplier", "Choose ...", nullptr));
        btn_clear->setText(QCoreApplication::translate("New_supplier", "Clear", nullptr));
        btn_save->setText(QCoreApplication::translate("New_supplier", "Save", nullptr));
    } // retranslateUi

};

namespace Ui {
    class New_supplier: public Ui_New_supplier {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEW_SUPPLIER_H
